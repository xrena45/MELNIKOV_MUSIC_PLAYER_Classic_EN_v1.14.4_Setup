struct Uniforms {
    resolution_time : vec4<f32>,
    audio : vec4<f32>,
    scene : vec4<f32>,
};

@group(0) @binding(0)
var<uniform> u : Uniforms;

struct VsOut {
    @builtin(position) pos : vec4<f32>,
    @location(0) uv : vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vertex_index : u32) -> VsOut {
    var positions = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -1.0),
        vec2<f32>( 3.0, -1.0),
        vec2<f32>(-1.0,  3.0)
    );
    var out : VsOut;
    let p = positions[vertex_index];
    out.pos = vec4<f32>(p, 0.0, 1.0);
    out.uv = p * 0.5 + vec2<f32>(0.5, 0.5);
    return out;
}

fn rot(p: vec2<f32>, a: f32) -> vec2<f32> {
    let c = cos(a);
    let s = sin(a);
    return vec2<f32>(p.x * c - p.y * s, p.x * s + p.y * c);
}

fn ring(r: f32, radius: f32, sharpness: f32) -> f32 {
    return exp(-abs(r - radius) * sharpness);
}

fn line_glow(v: f32, sharpness: f32) -> f32 {
    return exp(-abs(v) * sharpness);
}

fn palette(id: f32, x: f32) -> vec3<f32> {
    let q = fract(x);
    if (id < 0.5) {
        return 0.50 + 0.50 * cos(6.28318 * (q + vec3<f32>(0.00, 0.18, 0.42)));
    }
    if (id < 1.5) {
        return 0.50 + 0.50 * cos(6.28318 * (q + vec3<f32>(0.02, 0.34, 0.68)));
    }
    if (id < 2.5) {
        return 0.52 + 0.48 * cos(6.28318 * (q + vec3<f32>(0.08, 0.52, 0.82)));
    }
    if (id < 3.5) {
        return 0.52 + 0.48 * cos(6.28318 * (q + vec3<f32>(0.16, 0.74, 0.96)));
    }
    if (id < 4.5) {
        return 0.50 + 0.50 * cos(6.28318 * (q + vec3<f32>(0.56, 0.12, 0.86)));
    }
    return 0.54 + 0.46 * cos(6.28318 * (q + vec3<f32>(0.72, 0.28, 0.02)));
}

fn glyph_row(c: u32, row: u32) -> u32 {
    let r = min(row, 6u);
    if (c == 77u) { let a = array<u32,7>(17u,27u,21u,21u,17u,17u,17u); return a[r]; } // M
    if (c == 69u) { let a = array<u32,7>(31u,16u,16u,30u,16u,16u,31u); return a[r]; } // E
    if (c == 76u) { let a = array<u32,7>(16u,16u,16u,16u,16u,16u,31u); return a[r]; } // L
    if (c == 78u) { let a = array<u32,7>(17u,25u,21u,19u,17u,17u,17u); return a[r]; } // N
    if (c == 73u) { let a = array<u32,7>(31u,4u,4u,4u,4u,4u,31u); return a[r]; } // I
    if (c == 75u) { let a = array<u32,7>(17u,18u,20u,24u,20u,18u,17u); return a[r]; } // K
    if (c == 79u) { let a = array<u32,7>(14u,17u,17u,17u,17u,17u,14u); return a[r]; } // O
    if (c == 86u) { let a = array<u32,7>(17u,17u,17u,17u,17u,10u,4u); return a[r]; } // V
    if (c == 83u) { let a = array<u32,7>(15u,16u,16u,14u,1u,1u,30u); return a[r]; } // S
    if (c == 85u) { let a = array<u32,7>(17u,17u,17u,17u,17u,17u,14u); return a[r]; } // U
    if (c == 65u) { let a = array<u32,7>(14u,17u,17u,31u,17u,17u,17u); return a[r]; } // A
    if (c == 90u) { let a = array<u32,7>(31u,1u,2u,4u,8u,16u,31u); return a[r]; } // Z
    if (c == 84u) { let a = array<u32,7>(31u,4u,4u,4u,4u,4u,4u); return a[r]; } // T
    return 0u;
}

fn title_char(line: u32, idx: u32) -> u32 {
    if (line == 0u) {
        let w = array<u32,8>(77u,69u,76u,78u,73u,75u,79u,86u); // MELNIKOV
        return w[min(idx,7u)];
    }
    let w = array<u32,13>(86u,73u,83u,85u,65u,76u,73u,90u,65u,84u,73u,79u,78u); // VISUALIZATION
    return w[min(idx,12u)];
}

fn title_mask(uv: vec2<f32>, line: u32) -> f32 {
    var count = 8.0;
    var cy = 0.47;
    var cw = 0.055;
    var ch = 0.105;
    if (line == 1u) {
        count = 13.0;
        cy = 0.585;
        cw = 0.041;
        ch = 0.072;
    }
    let start = 0.5 - 0.5 * count * cw;
    let lx = (uv.x - start) / cw;
    let ly = (uv.y - (cy - 0.5 * ch)) / ch;
    if (lx < 0.0 || lx >= count || ly < 0.0 || ly >= 1.0) { return 0.0; }

    let idx = u32(floor(lx));
    let fx = fract(lx);
    let gx = u32(floor(fx * 6.0));
    let gy = u32(floor(ly * 7.0));
    if (gx >= 5u || gy >= 7u) { return 0.0; }

    let bits = glyph_row(title_char(line, idx), gy);
    let bit = (bits >> (4u - gx)) & 1u;
    return f32(bit);
}

fn startup_title(uv: vec2<f32>, t: f32) -> vec3<f32> {
    let fade_in = smoothstep(0.05, 0.45, t);
    let fade_out = 1.0 - smoothstep(2.55, 3.35, t);
    let fade = fade_in * fade_out;
    if (fade <= 0.001) { return vec3<f32>(0.0); }

    let m = max(title_mask(uv, 0u), title_mask(uv, 1u));
    let o1 = vec2<f32>(0.0025, 0.0025);
    let o2 = vec2<f32>(0.0050, 0.0050);
    let glow = max(
        max(title_mask(uv + o1,0u), title_mask(uv - o1,0u)),
        max(title_mask(uv + o1,1u), title_mask(uv - o1,1u))
    );
    let depth = max(title_mask(uv + o2,0u), title_mask(uv + o2,1u));

    let rainbow = 0.52 + 0.48 * cos(
        6.28318 * (uv.x * 0.95 + t * 0.10 + vec3<f32>(0.00,0.33,0.67))
    );
    var col = rainbow * m * 2.2;
    col += rainbow * glow * 0.65;
    col += vec3<f32>(0.08,0.18,0.50) * depth * 0.95;
    return col * fade;
}

// Returns: x=main field, y=secondary glow, z=spark/line field, w=color phase.
fn scene_signal(p0: vec2<f32>, t: f32, bass: f32, mids: f32, highs: f32, energy: f32, scene: f32) -> vec4<f32> {
    var p = p0;
    let r0 = length(p);
    let a0 = atan2(p.y, p.x);
    var main = 0.0;
    var glow = 0.0;
    var spark = 0.0;
    var phase = 0.0;

    if (scene < 0.5) {
        // 01 Aura Triad / boomerang family.
        p = rot(p, -t * (0.18 + energy * 0.25));
        let r = length(p);
        let a = atan2(p.y, p.x);
        let tri = abs(cos(a * 3.0)) * 0.24;
        main = ring(r, 0.42 + tri + bass * 0.09, 22.0);
        glow = ring(r, 0.30 + tri * 0.8, 8.0);
        spark = pow(abs(sin(a * 6.0 - t * 1.4 + r * 9.0)), 18.0);
        phase = a * 0.16 + r * 0.55 + t * 0.05;
    } else if (scene < 1.5) {
        // 02 Concentric orbital rings.
        let r = r0;
        let rings = 0.5 + 0.5 * sin(r * (35.0 + mids * 14.0) - t * (3.0 + energy * 2.0));
        main = pow(rings, 10.0);
        glow = ring(r, 0.48 + bass * 0.10, 14.0) + ring(r, 0.72 - bass * 0.06, 18.0);
        spark = pow(abs(sin(a0 * 18.0 + t * 1.8)), 28.0) * ring(r, 0.62, 4.0);
        phase = r * 0.75 - t * 0.06;
    } else if (scene < 2.5) {
        // 03 Lotus / mandala petals.
        let a = a0 + t * 0.18;
        let pet = 0.32 + 0.20 * abs(cos(a * 8.0 + sin(t) * 0.35));
        main = ring(r0, pet + bass * 0.08, 28.0);
        glow = ring(r0, pet + 0.16 + mids * 0.04, 9.0);
        spark = pow(abs(sin(a * 16.0 - t * 2.0)), 22.0) * exp(-r0 * 1.5);
        phase = a * 0.12 + r0 * 0.4;
    } else if (scene < 3.5) {
        // 04 Crossing ribbon waves.
        let q = rot(p, -0.12 * sin(t * 0.4));
        let w1 = line_glow(q.y - 0.24 * sin(q.x * 4.0 - t * (1.4 + energy)), 18.0);
        let w2 = line_glow(q.y + 0.22 * sin(q.x * 5.2 + t * 1.1), 22.0);
        let w3 = line_glow(q.y - 0.34 * sin(q.x * 2.7 + t * 0.7), 13.0);
        main = max(w1, w2);
        glow = w3 + 0.25 * (w1 + w2);
        spark = pow(abs(sin(q.x * 15.0 + t * 2.0)), 24.0) * main;
        phase = q.x * 0.24 + t * 0.04;
    } else if (scene < 4.5) {
        // 05 Spiral galaxy vortex.
        let r = r0;
        let a = a0;
        let spiral = sin(a * 5.0 + r * (13.0 + mids * 6.0) - t * (2.2 + energy * 1.6));
        main = pow(0.5 + 0.5 * spiral, 7.0) * exp(-r * 0.85);
        glow = ring(r, 0.52 + 0.05 * sin(t * 1.4), 8.0);
        spark = pow(abs(sin(a * 11.0 - t * 1.7 + r * 8.0)), 20.0);
        phase = a * 0.18 + r * 0.35;
    } else if (scene < 5.5) {
        // 06 Luminous wave mesh.
        let q = p * (3.0 + mids * 0.7);
        let gx = line_glow(sin(q.x * 2.2 + t) - q.y * 0.3, 8.0);
        let gy = line_glow(sin(q.y * 2.5 - t * 1.2) - q.x * 0.25, 9.0);
        main = max(gx, gy) * 0.9;
        glow = 0.35 * (gx + gy) + ring(r0, 0.78, 7.0);
        spark = pow(abs(sin((q.x + q.y) * 7.0 - t * 2.5)), 24.0) * main;
        phase = (q.x + q.y) * 0.08 + t * 0.03;
    } else if (scene < 6.5) {
        // 07 Faceted aura arch.
        let q = rot(p, 0.08 * sin(t * 0.55));
        let arch = abs(q.y + 0.35 - 0.78 * abs(q.x));
        let inner = abs(q.y + 0.05 - 0.45 * abs(q.x));
        main = line_glow(arch, 26.0);
        glow = line_glow(inner, 10.0) + main * 0.35;
        spark = pow(abs(sin((q.x - q.y) * 13.0 + t * 1.8)), 26.0) * main;
        phase = q.x * 0.18 - q.y * 0.12;
    } else if (scene < 7.5) {
        // 08 Explosive nebula ring.
        let jag = 0.045 * sin(a0 * 17.0 + t * 2.4) + 0.025 * sin(a0 * 31.0 - t * 3.1);
        main = ring(r0, 0.48 + jag + bass * 0.10, 26.0);
        glow = ring(r0, 0.48, 7.0);
        spark = pow(abs(sin(a0 * 41.0 + t * 4.0)), 18.0) * main;
        phase = a0 * 0.22 + t * 0.08;
    } else if (scene < 8.5) {
        // 09 Spherical flower / overlapping loops.
        let a = a0 + t * 0.15;
        let pet = 0.36 + 0.16 * cos(a * 6.0);
        main = ring(r0, pet, 23.0) + 0.65 * ring(r0, 0.58 + 0.08 * sin(a * 4.0), 20.0);
        glow = ring(r0, 0.46, 6.0);
        spark = pow(abs(sin(a * 12.0 - t * 1.5)), 24.0) * exp(-r0);
        phase = a * 0.15 + r0 * 0.3;
    } else if (scene < 9.5) {
        // 10 Resonance funnel / hourglass.
        let q = rot(p, 0.05 * sin(t));
        let cone = abs(abs(q.x) - (0.12 + 0.62 * abs(q.y)));
        main = line_glow(cone, 22.0);
        glow = ring(length(q), 0.26 + 0.10 * sin(t * 1.4), 8.0) + main * 0.3;
        spark = pow(abs(sin(q.y * 24.0 - t * 3.0)), 20.0) * main;
        phase = q.y * 0.28 + t * 0.04;
    } else if (scene < 10.5) {
        // 11 Mirrored energy wings.
        let q = p;
        let wing = abs(q.y - 0.30 * sin(abs(q.x) * 5.0 - t * 1.1));
        main = line_glow(wing, 20.0) * smoothstep(0.05, 0.35, abs(q.x));
        glow = line_glow(q.y - 0.48 * sin(abs(q.x) * 2.4 + t * 0.7), 9.0);
        spark = pow(abs(sin(abs(q.x) * 18.0 + t * 2.2)), 24.0) * main;
        phase = abs(q.x) * 0.35 + q.y * 0.12;
    } else if (scene < 11.5) {
        // 12 Sound constellation / orbiting nodes.
        let q = rot(p, t * 0.07);
        let r = length(q);
        let a = atan2(q.y, q.x);
        let orbit = ring(r, 0.42 + 0.12 * sin(a * 3.0 + t), 18.0);
        let nodes = pow(abs(sin(a * 9.0 - t * 1.8)), 30.0) * orbit;
        main = orbit * 0.55 + nodes;
        glow = ring(r, 0.68, 8.0) + 0.5 * nodes;
        spark = pow(abs(sin(a * 27.0 + t * 3.2)), 30.0) * ring(r, 0.68, 3.5);
        phase = a * 0.2 + t * 0.05;
    } else if (scene < 12.5) {
        // 13 Dense 12-fold mandala.
        let a = a0 - t * 0.22;
        let wave = 0.5 + 0.5 * cos(a * 12.0 + r0 * 9.0 - t * 1.4);
        main = pow(wave, 7.0) * exp(-r0 * 0.75);
        glow = ring(r0, 0.36 + 0.12 * wave + bass * 0.05, 9.0);
        spark = pow(abs(sin(a * 24.0 + t * 2.0)), 26.0) * exp(-r0 * 1.2);
        phase = a * 0.13 + r0 * 0.42;
    } else if (scene < 13.5) {
        // 14 Deep tunnel rings.
        let warped = r0 + 0.08 * sin(a0 * 4.0 - t * 0.8);
        let bands = 0.5 + 0.5 * sin(1.0 / (warped + 0.10) * 14.0 - t * (4.0 + energy * 2.0));
        main = pow(bands, 9.0) * exp(-r0 * 0.55);
        glow = exp(-r0 * 1.4) * (0.5 + 0.5 * sin(a0 * 5.0 + t));
        spark = pow(abs(sin(a0 * 16.0 - t * 2.2)), 22.0) * exp(-r0);
        phase = r0 * 0.7 - t * 0.08;
    } else if (scene < 14.5) {
        // 15 Interference circles.
        let c1 = length(p - vec2<f32>(0.32 * sin(t * 0.5), 0.0));
        let c2 = length(p + vec2<f32>(0.32 * sin(t * 0.5), 0.0));
        let f = 0.5 + 0.5 * sin((c1 - c2) * (35.0 + mids * 15.0) + t * 2.0);
        main = pow(f, 8.0) * exp(-r0 * 0.55);
        glow = ring(c1, 0.45, 9.0) + ring(c2, 0.45, 9.0);
        spark = pow(abs(sin((c1 + c2) * 22.0 - t * 3.0)), 24.0);
        phase = (c1 - c2) * 0.8 + t * 0.04;
    } else if (scene < 15.5) {
        // 16 Rotating fan rays.
        let a = a0 + t * (0.25 + energy * 0.2);
        let rays = pow(abs(sin(a * (10.0 + highs * 6.0))), 18.0);
        main = rays * exp(-r0 * 0.7);
        glow = ring(r0, 0.52 + bass * 0.08, 8.0);
        spark = pow(abs(sin(a * 31.0 - t * 2.8)), 30.0) * exp(-r0);
        phase = a * 0.14;
    } else if (scene < 16.5) {
        // 17 Plasma arcs.
        let q = rot(p, -t * 0.12);
        let a1 = line_glow(q.y - 0.38 * sin(q.x * 3.0 + t * 1.4), 18.0);
        let a2 = line_glow(q.x - 0.36 * sin(q.y * 3.4 - t * 1.1), 18.0);
        main = max(a1, a2);
        glow = 0.45 * (a1 + a2) + ring(r0, 0.72, 7.0);
        spark = pow(abs(sin((q.x * q.y) * 32.0 + t * 3.0)), 20.0) * main;
        phase = (q.x - q.y) * 0.22 + t * 0.05;
    } else if (scene < 17.5) {
        // 18 Rotating polygon crystal.
        let a = a0 - t * 0.18;
        let sectors = 6.0;
        let k = 3.14159265 / sectors;
        let d = cos(floor(0.5 + a / (2.0 * k)) * (2.0 * k) - a) * r0;
        main = ring(d, 0.42 + bass * 0.07, 28.0);
        glow = ring(d, 0.58, 9.0);
        spark = pow(abs(sin(a * 18.0 + t * 2.2)), 28.0) * main;
        phase = a * 0.18 + d * 0.4;
    } else if (scene < 18.5) {
        // 19 Spectral ribbon field.
        let q = rot(p, t * 0.06);
        let f1 = line_glow(q.y - 0.22 * sin(q.x * 6.0 + t * 1.6), 18.0);
        let f2 = line_glow(q.y + 0.34 * sin(q.x * 3.2 - t * 1.0), 13.0);
        let f3 = line_glow(q.x - 0.30 * sin(q.y * 4.0 + t * 1.3), 15.0);
        main = max(f1, max(f2, f3));
        glow = 0.35 * (f1 + f2 + f3);
        spark = pow(abs(sin((q.x + q.y) * 16.0 - t * 2.4)), 24.0) * main;
        phase = q.x * 0.18 + q.y * 0.14 + t * 0.04;
    } else if (scene < 19.5) {
        // 20 Maximal energy bloom.
        let a = a0 + t * 0.14;
        let petals = pow(0.5 + 0.5 * sin(a * 9.0 + r0 * 12.0 - t * 2.1), 6.0);
        let rr = ring(r0, 0.42 + 0.08 * sin(a * 5.0 + t), 15.0);
        let vortex = pow(0.5 + 0.5 * sin(a * 6.0 + 15.0 / (r0 + 0.18) - t * 3.0), 6.0) * exp(-r0);
        main = clamp(petals * 0.65 + rr * 0.75 + vortex * 0.55, 0.0, 1.5);
        glow = ring(r0, 0.66, 7.0) + exp(-r0 * 1.5) * 0.4;
        spark = pow(abs(sin(a * 29.0 - t * 3.5)), 24.0) * (0.35 + rr);
        phase = a * 0.16 + r0 * 0.38 + t * 0.05;
    } else if (scene < 20.5) {
        // 21 Pseudo-3D prism tunnel.
        let z = 1.0 / (r0 + 0.16);
        let facets = pow(abs(cos(a0 * 6.0 + t * 0.35)), 10.0);
        main = pow(0.5 + 0.5 * sin(z * 11.0 - t * (4.2 + energy)), 8.0) * (0.45 + facets);
        glow = ring(r0, 0.56 + 0.06 * sin(t), 8.0) + facets * exp(-r0 * 0.9);
        spark = pow(abs(sin(a0 * 18.0 + z * 2.0 - t * 2.0)), 24.0) * exp(-r0 * 0.7);
        phase = z * 0.12 + a0 * 0.15;
    } else if (scene < 21.5) {
        // 22 Orbital plasma spheres.
        let c1 = length(p - vec2<f32>(0.42 * cos(t*0.6), 0.28 * sin(t*0.7)));
        let c2 = length(p + vec2<f32>(0.36 * sin(t*0.5), 0.24 * cos(t*0.8)));
        main = ring(c1, 0.20 + bass*0.05, 22.0) + ring(c2, 0.16 + mids*0.04, 24.0);
        glow = ring(r0, 0.62, 9.0) + 0.5 * ring(c1,0.31,8.0);
        spark = pow(abs(sin(a0*14.0 - t*2.4)),24.0) * ring(r0,0.62,4.0);
        phase = c1*0.7 - c2*0.45 + t*0.04;
    } else if (scene < 22.5) {
        // 23 Layered 3D lotus.
        let a = a0 + t*0.12;
        let d1 = 0.30 + 0.16*abs(cos(a*7.0));
        let d2 = 0.48 + 0.12*abs(cos(a*7.0 + 0.9));
        let d3 = 0.68 + 0.08*abs(cos(a*7.0 + 1.8));
        main = ring(r0,d1,28.0) + 0.75*ring(r0,d2,25.0) + 0.45*ring(r0,d3,20.0);
        glow = exp(-r0*1.4) + ring(r0,0.80,6.0);
        spark = pow(abs(sin(a*21.0-t*2.0)),26.0)*exp(-r0);
        phase = a*0.14 + r0*0.55;
    } else if (scene < 23.5) {
        // 24 Perspective energy wings.
        let q = p / (1.0 + 0.28*abs(p.y));
        let wing = abs(q.y - 0.26*sin(abs(q.x)*5.5 - t*1.4));
        main = line_glow(wing,24.0)*smoothstep(0.08,0.35,abs(q.x));
        glow = line_glow(q.y - 0.46*sin(abs(q.x)*2.8+t*0.8),10.0);
        spark = pow(abs(sin(abs(q.x)*24.0+t*2.8)),24.0)*main;
        phase = abs(q.x)*0.38 - q.y*0.12;
    } else if (scene < 24.5) {
        // 25 Crystal resonance chamber.
        let a = a0 - t*0.10;
        let sectors = 8.0;
        let k = 3.14159265 / sectors;
        let d = cos(floor(0.5 + a/(2.0*k))*(2.0*k)-a)*r0;
        let shell = 0.5 + 0.5*sin((1.0/(abs(d)+0.14))*8.0 - t*2.7);
        main = pow(shell,8.0)*exp(-r0*0.5);
        glow = ring(d,0.44,20.0)+ring(d,0.66,10.0);
        spark = pow(abs(sin(a*32.0-t*2.0)),28.0)*main;
        phase = d*0.65 + a*0.14;
    } else if (scene < 25.5) {
        // 26 Orbital core.
        let q1 = rot(p,t*0.22);
        let q2 = rot(p,-t*0.16);
        let e1 = abs(length(vec2<f32>(q1.x, q1.y*1.7))-0.54);
        let e2 = abs(length(vec2<f32>(q2.x*1.7, q2.y))-0.54);
        main = exp(-e1*28.0)+exp(-e2*28.0);
        glow = ring(r0,0.25+bass*0.05,12.0)+ring(r0,0.72,7.0);
        spark = pow(abs(sin(a0*20.0+t*3.0)),26.0)*ring(r0,0.72,4.0);
        phase = a0*0.22 + r0*0.33;
    } else if (scene < 26.5) {
        // 27 Aurora lattice / 3D wave grid.
        let depth = 1.0/(0.22 + abs(p.y+0.9));
        let gx = line_glow(sin((p.x*7.0)*depth + t*1.2) - p.y*0.2,10.0);
        let gy = line_glow(fract((p.y+1.0)*5.0 + 0.10*sin(p.x*4.0+t))-0.5,18.0);
        main = max(gx,gy)*exp(-abs(p.y)*0.4);
        glow = 0.35*(gx+gy)+ring(r0,0.82,6.0);
        spark = pow(abs(sin((p.x+p.y)*18.0-t*2.2)),24.0)*main;
        phase = p.x*0.18 + p.y*0.10;
    } else if (scene < 27.5) {
        // 28 Double-helix bloom.
        let yy = p.y*4.0;
        let hx1 = 0.34*sin(yy*2.2 - t*1.4);
        let hx2 = -hx1;
        let h1 = line_glow(p.x-hx1,25.0);
        let h2 = line_glow(p.x-hx2,25.0);
        main = (h1+h2)*exp(-abs(p.y)*0.35);
        glow = ring(r0,0.66,7.0)+0.25*(h1+h2);
        spark = pow(abs(sin(yy*9.0+t*2.5)),26.0)*(h1+h2);
        phase = yy*0.10 + t*0.04;
    } else if (scene < 28.5) {
        // 29 Cosmic dome and shockwaves.
        let dome = abs(r0 - (0.76 - 0.10*p.y));
        let wave = 0.5 + 0.5*sin(r0*(28.0+mids*8.0)-t*(3.5+energy));
        main = line_glow(dome,18.0)+0.55*pow(wave,9.0)*smoothstep(-0.8,0.4,p.y);
        glow = ring(r0,0.34+bass*0.07,10.0)+ring(r0,0.62,8.0);
        spark = pow(abs(sin(a0*24.0-t*2.8)),28.0)*ring(r0,0.62,4.0);
        phase = r0*0.6 - t*0.05;
    } else {
        // 30 Spectrum portal wings.
        let portal = pow(0.5+0.5*sin(13.0/(r0+0.16)-t*(3.8+energy)),8.0)*exp(-r0*0.6);
        let wing = line_glow(p.y-0.28*sin(abs(p.x)*5.0-t*1.2),18.0)*smoothstep(0.10,0.35,abs(p.x));
        main = clamp(portal*0.8 + wing,0.0,1.6);
        glow = ring(r0,0.52+bass*0.08,9.0)+0.4*wing;
        spark = pow(abs(sin(a0*30.0+t*3.0)),28.0)*(0.25+portal);
        phase = a0*0.18 + r0*0.48;
    }

    // Audio reactivity is common to all 30 families.
    let beat = clamp(u.scene.z, 0.0, 1.0);
    let onset = clamp(u.scene.w, 0.0, 1.0);
    main *= 0.78 + energy * 0.62 + beat * 0.38;
    glow *= 0.72 + bass * 0.72 + beat * 0.52;
    spark *= 0.45 + highs * 1.45 + onset * 0.95;
    return vec4<f32>(main, glow, spark, phase);
}

@fragment
fn fs_main(in: VsOut) -> @location(0) vec4<f32> {
    let res = max(u.resolution_time.xy, vec2<f32>(1.0, 1.0));
    let t = u.resolution_time.z;
    let scene = u.scene.x;
    let palette_id = u.scene.y;
    let beat = clamp(u.scene.z, 0.0, 1.0);
    let onset = clamp(u.scene.w, 0.0, 1.0);

    let bass = clamp(u.audio.x * 1.90, 0.0, 1.0);
    let mids = clamp(u.audio.y * 1.70, 0.0, 1.0);
    let highs = clamp(u.audio.z * 1.60, 0.0, 1.0);
    let energy = clamp(u.audio.w * 1.80, 0.0, 1.0);

    var p = in.uv * 2.0 - 1.0;
    p.x *= res.x / res.y;

    // Universal breathing motion + explicit beat punch.
    let breathe = 1.0 + 0.035 * sin(t * 1.35) + bass * 0.08 + beat * 0.13;
    p /= breathe;
    p = rot(p, (beat * 0.022 + onset * 0.012) * sin(t * 7.0));

    let s = scene_signal(p, t, bass, mids, highs, energy, scene);
    let field = clamp(s.x, 0.0, 1.4);
    let glow = clamp(s.y, 0.0, 1.8);
    let spark = clamp(s.z, 0.0, 1.8);

    let r = length(p);
    let edge = clamp(1.20 - r * 0.42, 0.0, 1.0);
    let base = vec3<f32>(0.0015, 0.004, 0.014);

    let c1 = palette(palette_id, s.w + t * 0.025);
    let c2 = palette(palette_id, s.w + 0.22 + mids * 0.08);
    let c3 = palette(palette_id, s.w + 0.52 + highs * 0.12);

    var col = base;
    col += c1 * field * 1.05;
    col += c2 * glow * 0.62;
    col += c3 * spark * (0.30 + highs * 0.35);

    // Beat shockwave: fast central hit that expands as the pulse decays.
    let beat_radius = 0.18 + (1.0 - beat) * 0.62;
    let beat_wave = ring(r, beat_radius, 26.0) * beat;
    col += palette(palette_id, 0.12 + t*0.06) * beat_wave * 1.35;
    col += vec3<f32>(1.0,0.88,0.72) * onset * exp(-r*3.2) * 0.42;

    // Soft pseudo-bloom without extra render passes.
    col += c1 * field * field * (0.28 + energy * 0.28);
    col += vec3<f32>(1.0) * spark * spark * (0.08 + highs * 0.18);

    // Keep dark background and bright neon structures.
    col *= edge * (0.82 + energy * 0.38 + beat * 0.22);
    col = pow(max(col, vec3<f32>(0.0)), vec3<f32>(0.86));

    // Startup identity: multicolor pseudo-3D MELNIKOV VISUALIZATION.
    col += startup_title(in.uv, t);

    return vec4<f32>(col, 1.0);
}
