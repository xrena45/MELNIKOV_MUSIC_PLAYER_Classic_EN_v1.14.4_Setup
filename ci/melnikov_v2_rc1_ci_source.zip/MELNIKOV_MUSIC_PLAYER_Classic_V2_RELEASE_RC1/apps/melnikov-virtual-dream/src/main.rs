#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::{
    fs::OpenOptions, io::Write, panic, sync::{Arc, Mutex}, thread, time::Instant,
};
use bytemuck::{Pod, Zeroable};
use melnikov_ipc::{connect_or_start_bridge, read_server_loop, send, BridgeCommand, ServerMessage};
use wgpu::util::DeviceExt;
use winit::{
    application::ApplicationHandler, dpi::LogicalSize, event::WindowEvent,
    event_loop::{ActiveEventLoop, ControlFlow, EventLoop, EventLoopProxy},
    window::{Window, WindowAttributes, WindowId},
};

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct Uniforms {
    resolution_time: [f32; 4],
    audio: [f32; 4],
    scene: [f32; 4],
}

#[derive(Default, Clone, Copy)]
struct AudioLevels {
    bass: f32,
    mids: f32,
    highs: f32,
    energy: f32,
    beat: f32,
    onset: f32,
}


fn log_line(message: &str) {
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            let path = dir.join("Melnikov_Virtual_Dream.log");
            if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
                let _ = writeln!(file, "{message}");
            }
        }
    }
}

fn show_error(title: &str, message: &str) {
    log_line(&format!("{title}: {message}"));
    rfd::MessageDialog::new()
        .set_title(title)
        .set_description(message)
        .set_level(rfd::MessageLevel::Error)
        .show();
}

struct GpuState {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    pipeline: wgpu::RenderPipeline,
    uniform_buffer: wgpu::Buffer,
    bind_group: wgpu::BindGroup,
    frame_count: u64,
}

impl GpuState {
    async fn new_from_surface(
        instance: wgpu::Instance,
        surface: wgpu::Surface<'static>,
        width: u32,
        height: u32,
    ) -> Result<Self, String> {
        let width = width.max(1);
        let height = height.max(1);

        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::LowPower,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .map_err(|e| format!("GPU adapter error: {e}"))?;

        let info = adapter.get_info();
        log_line(&format!(
            "GPU: name={} backend={:?} device_type={:?} driver={}",
            info.name, info.backend, info.device_type, info.driver
        ));

        let adapter_limits = adapter.limits();
        log_line(&format!(
            "GPU limits: max_texture_dimension_2d={}",
            adapter_limits.max_texture_dimension_2d
        ));

        let (device, queue) = adapter
            .request_device(&wgpu::DeviceDescriptor {
                label: Some("Melnikov Virtual Dream Device"),
                required_features: wgpu::Features::empty(),
                // IMPORTANT: do not use downlevel_defaults() here. Its 2048 px
                // texture limit breaks HiDPI Windows surfaces (e.g. 1100x700
                // logical pixels becomes 2200x1400 physical pixels at 200%).
                // The adapter already reports limits it can actually support.
                required_limits: adapter_limits,
                experimental_features: wgpu::ExperimentalFeatures::disabled(),
                memory_hints: wgpu::MemoryHints::MemoryUsage,
                trace: wgpu::Trace::Off,
            })
            .await
            .map_err(|e| format!("GPU device error: {e}"))?;

        let mut config = surface
            .get_default_config(&adapter, width, height)
            .ok_or("Surface configuration unavailable")?;

        config.present_mode = wgpu::PresentMode::Fifo;
        log_line(&format!(
            "Surface: format={:?} size={}x{} present={:?}",
            config.format, config.width, config.height, config.present_mode
        ));
        surface.configure(&device, &config);

        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Virtual Dream Shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("dream.wgsl").into()),
        });

        let uniforms = Uniforms {
            resolution_time: [width as f32, height as f32, 0.0, 0.0],
            audio: [0.0; 4],
            scene: [0.0, 0.0, 0.0, 0.0],
        };

        let uniform_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Virtual Dream Uniforms"),
            contents: bytemuck::bytes_of(&uniforms),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });

        let bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Virtual Dream BGL"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });

        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Virtual Dream Bind Group"),
            layout: &bgl,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: uniform_buffer.as_entire_binding(),
            }],
        });

        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Virtual Dream Pipeline Layout"),
            bind_group_layouts: &[&bgl],
            immediate_size: 0,
        });

        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Virtual Dream Pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                compilation_options: Default::default(),
                buffers: &[],
            },
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                compilation_options: Default::default(),
                targets: &[Some(wgpu::ColorTargetState {
                    format: config.format,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            multiview_mask: None,
            cache: None,
        });

        Ok(Self {
            surface,
            device,
            queue,
            config,
            pipeline,
            uniform_buffer,
            bind_group,
            frame_count: 0,
        })
    }

    fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 {
            return;
        }
        self.config.width = width;
        self.config.height = height;
        self.surface.configure(&self.device, &self.config);
    }

    fn render(&mut self, time: f32, audio: AudioLevels) {
        self.frame_count += 1;
        if self.frame_count == 1 {
            log_line("Renderer: first frame requested");
        }
        if self.frame_count == 60 {
            log_line("Renderer: 60 frames rendered");
        }

        let uniforms = Uniforms {
            resolution_time: [
                self.config.width as f32,
                self.config.height as f32,
                time,
                0.0,
            ],
            audio: [audio.bass, audio.mids, audio.highs, audio.energy],
            // 30 scene families x 6 palettes = 180 deterministic combinations.
            // A new combination appears every 10 seconds.
            // scene.z = beat pulse, scene.w = onset/transient pulse.
            scene: {
                let slot = (time / 10.0).floor() as u32 % 180;
                let scene_id = slot % 30;
                let palette_id = (slot / 30) % 6;
                [scene_id as f32, palette_id as f32, audio.beat, audio.onset]
            },
        };
        self.queue
            .write_buffer(&self.uniform_buffer, 0, bytemuck::bytes_of(&uniforms));

        let frame = match self.surface.get_current_texture() {
            Ok(frame) => frame,
            Err(wgpu::SurfaceError::Lost | wgpu::SurfaceError::Outdated) => {
                log_line("Surface: Lost/Outdated; reconfigure");
                self.surface.configure(&self.device, &self.config);
                return;
            }
            Err(wgpu::SurfaceError::Timeout) => {
                log_line("Surface: Timeout");
                return;
            }
            Err(wgpu::SurfaceError::OutOfMemory) => {
                log_line("Surface: OutOfMemory");
                return;
            }
            Err(err) => {
                log_line(&format!("Surface error: {err:?}"));
                return;
            }
        };

        let view = frame.texture.create_view(&Default::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("Virtual Dream Encoder"),
        });

        // Render probe: even if the shader output is black, this clear color must be visible.
        let breathe = ((time * 0.7).sin() * 0.5 + 0.5) as f64;
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("Virtual Dream Pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    depth_slice: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color {
                            r: 0.002,
                            g: 0.02 + 0.025 * breathe,
                            b: 0.08 + 0.06 * breathe,
                            a: 1.0,
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
                multiview_mask: None,
            });

            pass.set_pipeline(&self.pipeline);
            pass.set_bind_group(0, &self.bind_group, &[]);
            pass.draw(0..3, 0..1);
        }

        self.queue.submit(Some(encoder.finish()));
        frame.present();
    }
}


enum UserEvent {
    GpuReady(Result<GpuState, String>),
}

struct DreamApp {
    audio_levels: Arc<Mutex<AudioLevels>>,
    window: Option<Arc<Window>>,
    gpu: Option<GpuState>,
    start: Instant,
    gpu_init_started: bool,
    proxy: EventLoopProxy<UserEvent>,
}

impl DreamApp {
    fn new(
        audio_levels: Arc<Mutex<AudioLevels>>,
        proxy: EventLoopProxy<UserEvent>,
    ) -> Self {
        Self {
            audio_levels,
            window: None,
            gpu: None,
            start: Instant::now(),
            gpu_init_started: false,
            proxy,
        }
    }

    fn start_gpu_init(&mut self) {
        if self.gpu_init_started {
            return;
        }

        let Some(window) = self.window.as_ref().cloned() else {
            return;
        };

        self.gpu_init_started = true;
        window.set_title("MELNIKOV VIRTUAL DREAM v.0.9 — инициализация GPU...");

        // IMPORTANT: on Windows the raw HWND must be obtained on the winit/UI thread.
        // Creating the wgpu Surface in a worker thread causes:
        // "the underlying handle is not available".
        log_line("Stage 5A: creating GPU surface on UI thread");
        let size = window.inner_size();
        let instance = wgpu::Instance::default();
        let surface = match instance.create_surface(Arc::clone(&window)) {
            Ok(surface) => surface,
            Err(err) => {
                let _ = self.proxy.send_event(UserEvent::GpuReady(Err(format!(
                    "Surface error: {err}"
                ))));
                return;
            }
        };
        log_line("Stage 5A: surface created; GPU worker started");

        let proxy = self.proxy.clone();
        thread::spawn(move || {
            let result = pollster::block_on(GpuState::new_from_surface(
                instance,
                surface,
                size.width,
                size.height,
            ));
            let _ = proxy.send_event(UserEvent::GpuReady(result));
        });
    }
}

impl ApplicationHandler<UserEvent> for DreamApp {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_none() {
            let attrs = WindowAttributes::default()
                .with_title("MELNIKOV VIRTUAL DREAM v.0.9 — BEAT SYNC")
                .with_inner_size(LogicalSize::new(1100.0, 700.0))
                .with_min_inner_size(LogicalSize::new(720.0, 450.0));

            let window = match event_loop.create_window(attrs) {
                Ok(w) => Arc::new(w),
                Err(err) => {
                    show_error(
                        "Melnikov Virtual Dream v.0.9 — Window Error",
                        &format!("Не удалось создать окно визуализации:\n{err}")
                    );
                    event_loop.exit();
                    return;
                }
            };

            log_line("Stage 5: window created");
            self.window = Some(window);
        }

        self.start_gpu_init();
    }

    fn user_event(&mut self, event_loop: &ActiveEventLoop, event: UserEvent) {
        match event {
            UserEvent::GpuReady(Ok(mut gpu)) => {
                log_line("Stage 5B: GPU ready");
                if let Some(window) = self.window.as_ref() {
                    let size = window.inner_size();
                    gpu.resize(size.width, size.height);
                    window.set_title("MELNIKOV VIRTUAL DREAM v.0.9 — BEAT SYNC");
                    window.request_redraw();
                }
                self.gpu = Some(gpu);
            }
            UserEvent::GpuReady(Err(err)) => {
                show_error(
                    "Melnikov Virtual Dream v.0.9 — GPU Error",
                    &format!("Не удалось запустить GPU renderer:\n\n{err}")
                );
                event_loop.exit();
            }
        }
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        window_id: WindowId,
        event: WindowEvent,
    ) {
        let Some(window) = self.window.as_ref() else { return };
        if window.id() != window_id {
            return;
        }

        match event {
            WindowEvent::CloseRequested => {
                log_line("Window: close requested");
                event_loop.exit();
            }
            WindowEvent::Resized(size) => {
                if let Some(gpu) = self.gpu.as_mut() {
                    gpu.resize(size.width, size.height);
                }
            }
            WindowEvent::RedrawRequested => {
                if let Some(gpu) = self.gpu.as_mut() {
                    let audio = self.audio_levels.lock().map(|v| *v).unwrap_or_default();
                    let t = self.start.elapsed().as_secs_f32();
                    gpu.render(t, audio);
                }
            }
            _ => {}
        }
    }

    fn about_to_wait(&mut self, event_loop: &ActiveEventLoop) {
        if self.gpu.is_some() {
            event_loop.set_control_flow(ControlFlow::Poll);
            if let Some(window) = self.window.as_ref() {
                window.request_redraw();
            }
        } else {
            // Keep Windows responsive while the GPU worker initializes.
            event_loop.set_control_flow(ControlFlow::Wait);
        }
    }
}

fn main() {
    if let Ok(exe)=std::env::current_exe(){if let Some(dir)=exe.parent(){let _=std::fs::write(dir.join("Melnikov_Virtual_Dream.log"),"MELNIKOV VIRTUAL DREAM v0.9 — V2 bridge renderer\n");}}
    panic::set_hook(Box::new(|info|{let message=format!("PANIC: {info}");log_line(&message);rfd::MessageDialog::new().set_title("Melnikov Virtual Dream v0.9 — Critical Error").set_description(format!("Произошла критическая ошибка.\n\n{message}\n\nПодробности записаны в Melnikov_Virtual_Dream.log")).set_level(rfd::MessageLevel::Error).show();}));
    log_line("Stage 1: V2 bridge renderer started");
    let levels=Arc::new(Mutex::new(AudioLevels::default()));
    let (writer,reader)=match connect_or_start_bridge(){Ok(v)=>v,Err(e)=>{show_error("Melnikov Virtual Dream v0.9 — Bridge Error",&e);return;}};
    let shared=Arc::clone(&levels);
    read_server_loop(reader,move|message|{if let ServerMessage::State{state}=message{if let Ok(mut v)=shared.lock(){v.bass=state.bass;v.mids=state.mids;v.highs=state.highs;v.energy=state.energy;v.beat=state.beat;v.onset=state.onset;}}});
    let _=send(&writer,"VIRTUAL_DREAM",BridgeCommand::Status);
    let event_loop=match EventLoop::<UserEvent>::with_user_event().build(){Ok(v)=>v,Err(e)=>{show_error("Melnikov Virtual Dream v0.9 — Event Loop Error",&e.to_string());return;}};
    let proxy=event_loop.create_proxy();
    let mut app=DreamApp::new(levels,proxy);
    if let Err(err)=event_loop.run_app(&mut app){show_error("Melnikov Virtual Dream v0.9 — Runtime Error",&format!("Renderer завершился с ошибкой:\n\n{err}"));}
    log_line("Stage 6: application finished");
}
