#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::{
    sync::{mpsc, Arc},
    thread,
    time::{Duration, Instant},
};

use base64::{engine::general_purpose::STANDARD, Engine as _};
use gstreamer as gst;
use gstreamer::prelude::*;
use gstreamer_app as gst_app;
use melnikov_ipc::{
    connect_or_start_bridge, read_server_loop, send, BridgeCommand, PlayerSnapshot, ServerMessage,
};
use melnikov_platform::{default_geometry, load_window_geometry, save_window_geometry};
use tao::{
    dpi::{LogicalPosition, LogicalSize},
    event::{Event, WindowEvent},
    event_loop::{ControlFlow, EventLoop},
    window::WindowBuilder,
};
use url::Url;
use wry::WebViewBuilder;

const MODULE_HTML: &str = include_str!("../assets/module.html");
const SOURCE: &str = "VIDEO";

const INIT_JS: &str = r####"(() => {
  const post = payload => { try { window.ipc?.postMessage(JSON.stringify(payload)); } catch (_) {} };
  const mmss = seconds => { if(!Number.isFinite(seconds)||seconds<0)seconds=0; const s=Math.floor(seconds); return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'); };
  const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const applyTheme = t => { document.body.classList.remove('theme-dark','theme-light'); if(t==='dark')document.body.classList.add('theme-dark'); if(t==='light')document.body.classList.add('theme-light'); };
  window.MMP={post,mmss,esc,applyTheme,state:null};
  window.MMP_BRIDGE={onMessage(message){if(message?.event==='state'){window.MMP.state=message.state;applyTheme(message.state.theme||'turquoise');window.dispatchEvent(new CustomEvent('mmp-state',{detail:message.state}));}if(message?.event==='error')window.dispatchEvent(new CustomEvent('mmp-error',{detail:message.message}));}};
  window.MMP_VIDEO_FRAME = jpeg => {
    const img=document.getElementById('nativeVideoFrame');
    if(!img)return;
    img.src='data:image/jpeg;base64,'+jpeg;
    img.classList.add('ready');
  };
  window.MMP_VIDEO_CLEAR = label => {
    const img=document.getElementById('nativeVideoFrame');
    if(img){img.removeAttribute('src');img.classList.remove('ready');}
    const status=document.getElementById('nativeVideoStatus');
    if(status)status.textContent=label||'VIDEO R4';
  };
  window.addEventListener('DOMContentLoaded',()=>{
    const drag=document.querySelector('.vhead');
    if(drag)drag.addEventListener('pointerdown',e=>{if(e.button===0&&!e.target.closest('button'))post({cmd:'window:drag'});});
    post({cmd:'bridge:status'});
  });
})();

window.addEventListener('DOMContentLoaded',()=>{
  const {post,mmss,esc}=MMP;
  const head=document.querySelector('.vhead span:last-child');
  if(head){head.innerHTML='<button class="headbtn" data-v="min">−</button><button class="headbtn" data-v="max">□</button><button class="headbtn" data-v="close">×</button>';head.querySelector('[data-v=min]').onclick=()=>post({cmd:'window:minimize'});head.querySelector('[data-v=max]').onclick=()=>post({cmd:'window:maximize-toggle'});head.querySelector('[data-v=close]').onclick=()=>post({cmd:'window:close'});}
  document.querySelector('.play')?.addEventListener('click',()=>post({cmd:'media:toggle'}));
  const ovs=[...document.querySelectorAll('.ovbtn')];
  if(ovs[0])ovs[0].onclick=()=>post({cmd:'media:previous'});
  if(ovs[1])ovs[1].onclick=()=>post({cmd:'media:toggle'});
  if(ovs[2])ovs[2].onclick=()=>post({cmd:'media:next'});
  const actions=[...document.querySelectorAll('.actions button')];
  if(actions[0])actions[0].onclick=()=>post({cmd:'dialog:add-files'});
  if(actions[2])actions[2].onclick=()=>post({cmd:'dialog:add-folder'});
  document.getElementById('prevVideo')?.addEventListener('click',()=>post({cmd:'media:previous'}));
  document.getElementById('nextVideo')?.addEventListener('click',()=>post({cmd:'media:next'}));
  addEventListener('mmp-state',e=>{
    const s=e.detail;
    const l=document.querySelector('.ovlabel');if(l)l.textContent=`${mmss(s.position)} / ${mmss(s.duration)}`;
    const p=s.duration>0?Math.max(0,Math.min(100,s.position/s.duration*100)):0;
    const bar=document.querySelector('.ovbar');if(bar)bar.style.setProperty('--progress',p+'%');
    const play=document.querySelector('.play');if(play)play.textContent=s.playback==='playing'?'Ⅱ':'▶';
    if(ovs[1])ovs[1].textContent=s.playback==='playing'?'Ⅱ':'▶';
    const strip=document.getElementById('trackstrip');if(strip){
      const vids=s.playlist.filter(x=>x.media_kind==='video').slice(0,4);
      strip.innerHTML=vids.map(v=>`<div class="vitem" data-native-index="${v.index}"><div class="thumb">▶</div><div class="vtext">${esc(v.title)}</div></div>`).join('');
      strip.querySelectorAll('[data-native-index]').forEach(x=>x.onclick=()=>post({cmd:'media:select',index:Number(x.dataset.nativeIndex)}));
    }
  });
});
"####;

struct VideoPreview {
    playbin: gst::Pipeline,
    current_path: Option<String>,
    desired_playback: String,
    last_sync: Instant,
}

impl VideoPreview {
    fn new(frame_tx: mpsc::Sender<String>) -> Result<Self, String> {
        gst::init().map_err(|e| format!("GStreamer init failed: {e}"))?;
        let playbin = gst::ElementFactory::make("playbin3")
            .build()
            .map_err(|e| format!("playbin3 unavailable: {e}"))?
            .downcast::<gst::Pipeline>()
            .map_err(|_| "playbin3 is not a GstPipeline".to_string())?;

        let audio_sink = gst::ElementFactory::make("fakesink")
            .property("sync", true)
            .build()
            .map_err(|e| format!("fakesink unavailable: {e}"))?;
        playbin.set_property("audio-sink", &audio_sink);

        let convert = gst::ElementFactory::make("videoconvert")
            .build()
            .map_err(|e| format!("videoconvert unavailable: {e}"))?;
        let scale = gst::ElementFactory::make("videoscale")
            .build()
            .map_err(|e| format!("videoscale unavailable: {e}"))?;
        let rate = gst::ElementFactory::make("videorate")
            .build()
            .map_err(|e| format!("videorate unavailable: {e}"))?;
        let caps = gst::Caps::builder("video/x-raw")
            .field("width", 720_i32)
            .field("height", 405_i32)
            .field("framerate", gst::Fraction::new(10, 1))
            .build();
        let capsfilter = gst::ElementFactory::make("capsfilter")
            .property("caps", &caps)
            .build()
            .map_err(|e| format!("capsfilter unavailable: {e}"))?;
        let jpeg = gst::ElementFactory::make("jpegenc")
            .property("quality", 82_i32)
            .build()
            .map_err(|e| format!("jpegenc unavailable: {e}"))?;
        let appsink = gst::ElementFactory::make("appsink")
            .build()
            .map_err(|e| format!("appsink unavailable: {e}"))?
            .downcast::<gst_app::AppSink>()
            .map_err(|_| "appsink type unavailable".to_string())?;
        appsink.set_max_buffers(1);
        #[allow(deprecated)]
        appsink.set_drop(true);
        appsink.set_sync(true);

        let video_bin = gst::Bin::new();
        let appsink_element: &gst::Element = appsink.upcast_ref();
        video_bin
            .add_many([&convert, &scale, &rate, &capsfilter, &jpeg, appsink_element])
            .map_err(|e| e.to_string())?;
        convert.link(&scale).map_err(|e| e.to_string())?;
        scale.link(&rate).map_err(|e| e.to_string())?;
        rate.link(&capsfilter).map_err(|e| e.to_string())?;
        capsfilter.link(&jpeg).map_err(|e| e.to_string())?;
        jpeg.link(appsink_element).map_err(|e| e.to_string())?;
        let sink_target = convert
            .static_pad("sink")
            .ok_or_else(|| "videoconvert sink pad unavailable".to_string())?;
        let sink_ghost = gst::GhostPad::builder_with_target(&sink_target)
            .map_err(|e| e.to_string())?
            .name("sink")
            .build();
        sink_ghost.set_active(true).map_err(|e| e.to_string())?;
        video_bin.add_pad(&sink_ghost).map_err(|e| e.to_string())?;
        playbin.set_property("video-sink", &video_bin);

        let pull_sink = appsink.clone();
        thread::spawn(move || loop {
            if let Some(sample) = pull_sink.try_pull_sample(gst::ClockTime::from_mseconds(250)) {
                let Some(buffer) = sample.buffer() else { continue };
                let Ok(map) = buffer.map_readable() else { continue };
                let encoded = STANDARD.encode(map.as_slice());
                if frame_tx.send(encoded).is_err() {
                    break;
                }
            }
        });

        Ok(Self {
            playbin,
            current_path: None,
            desired_playback: "stopped".into(),
            last_sync: Instant::now() - Duration::from_secs(1),
        })
    }

    fn stop(&mut self) {
        let _ = self.playbin.set_state(gst::State::Null);
        self.current_path = None;
        self.desired_playback = "stopped".into();
    }

    fn apply_snapshot(&mut self, state: &PlayerSnapshot) -> Result<(), String> {
        if state.media_kind != "video" {
            self.stop();
            return Ok(());
        }
        let Some(path) = state.current_path.as_ref() else {
            self.stop();
            return Ok(());
        };

        if self.current_path.as_deref() != Some(path.as_str()) {
            let uri = Url::from_file_path(path)
                .map_err(|_| format!("Cannot convert video path to URI: {path}"))?;
            self.playbin
                .set_state(gst::State::Null)
                .map_err(|e| format!("VIDEO reset failed: {e:?}"))?;
            self.playbin.set_property("uri", uri.as_str());
            self.playbin
                .set_state(gst::State::Paused)
                .map_err(|e| format!("VIDEO preroll failed: {e:?}"))?;
            self.current_path = Some(path.clone());
            self.last_sync = Instant::now() - Duration::from_secs(1);
        }

        if self.desired_playback != state.playback {
            let target = if state.playback == "playing" {
                gst::State::Playing
            } else {
                gst::State::Paused
            };
            self.playbin
                .set_state(target)
                .map_err(|e| format!("VIDEO state change failed: {e:?}"))?;
            self.desired_playback = state.playback.clone();
        }

        if self.last_sync.elapsed() >= Duration::from_millis(350) {
            let local = self
                .playbin
                .query_position::<gst::ClockTime>()
                .map(|v| v.nseconds() as f64 / 1e9)
                .unwrap_or(0.0);
            if (local - state.position).abs() > 0.35 {
                let target = gst::ClockTime::from_nseconds((state.position.max(0.0) * 1e9) as u64);
                let _ = self
                    .playbin
                    .seek_simple(gst::SeekFlags::FLUSH | gst::SeekFlags::KEY_UNIT, target);
            }
            self.last_sync = Instant::now();
        }
        Ok(())
    }
}

impl Drop for VideoPreview {
    fn drop(&mut self) {
        let _ = self.playbin.set_state(gst::State::Null);
    }
}

fn main() {
    let (writer, reader) = match connect_or_start_bridge() {
        Ok(v) => v,
        Err(e) => {
            eprintln!("MELNIKOV {SOURCE}: {e}");
            return;
        }
    };

    let event_loop = EventLoop::new();
    let (sw, sh) = event_loop
        .primary_monitor()
        .map(|m| {
            let z = m.scale_factor();
            let s = m.size();
            (s.width as f64 / z, s.height as f64 / z)
        })
        .unwrap_or((1920.0, 1080.0));
    let mut geom = load_window_geometry("video").unwrap_or_else(|| default_geometry("video", sw, sh));
    let window = Arc::new(
        WindowBuilder::new()
            .with_title("MELNIKOV MUSIC PLAYER — Video R4")
            .with_inner_size(LogicalSize::new(geom.width as f64, geom.height as f64))
            .with_min_inner_size(LogicalSize::new(640.0, 420.0))
            .with_position(LogicalPosition::new(geom.x as f64, geom.y as f64))
            .with_resizable(true)
            .with_decorations(false)
            .build(&event_loop)
            .expect("window"),
    );

    let (ui_tx, ui_rx) = mpsc::channel::<String>();
    let (state_tx, state_rx) = mpsc::channel::<PlayerSnapshot>();
    read_server_loop(reader, move |message| {
        if let ServerMessage::State { state } = &message {
            let _ = state_tx.send(state.clone());
        }
        if let Ok(json) = serde_json::to_string(&message) {
            let _ = ui_tx.send(format!(
                "window.MMP_BRIDGE&&window.MMP_BRIDGE.onMessage({json});"
            ));
        }
    });

    let ipc_window = Arc::clone(&window);
    let ipc_writer = Arc::clone(&writer);
    let webview = WebViewBuilder::new()
        .with_html(MODULE_HTML)
        .with_initialization_script(INIT_JS)
        .with_hotkeys_zoom(false)
        .with_ipc_handler(move |request| {
            let body = request.body().as_str();
            let Ok(v) = serde_json::from_str::<serde_json::Value>(body) else { return };
            let cmd = v.get("cmd").and_then(|x| x.as_str()).unwrap_or("");
            match cmd {
                "window:minimize" => ipc_window.set_minimized(true),
                "window:maximize-toggle" => ipc_window.set_maximized(!ipc_window.is_maximized()),
                "window:drag" => { let _ = ipc_window.drag_window(); }
                "window:close" => ipc_window.set_visible(false),
                "bridge:status" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Status); }
                "media:play" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Play); }
                "media:pause" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Pause); }
                "media:toggle" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Toggle); }
                "media:stop" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Stop); }
                "media:previous" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Previous); }
                "media:next" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Next); }
                "media:clear" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Clear); }
                "media:seek-delta" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::SeekDelta { seconds: v.get("value").and_then(|x| x.as_f64()).unwrap_or(0.0) }); }
                "media:seek-ratio" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::SeekRatio { ratio: v.get("value").and_then(|x| x.as_f64()).unwrap_or(0.0) }); }
                "media:volume" => { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Volume { value: v.get("value").and_then(|x| x.as_f64()).unwrap_or(0.75) }); }
                "media:select" => { if let Some(i) = v.get("index").and_then(|x| x.as_u64()) { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Select { index: i as usize }); } }
                "media:remove" => { if let Some(i) = v.get("index").and_then(|x| x.as_u64()) { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Remove { index: i as usize }); } }
                "ui:theme" => { if let Some(t) = v.get("value").and_then(|x| x.as_str()) { let _ = send(&ipc_writer, SOURCE, BridgeCommand::Theme { theme: t.to_string() }); } }
                "eq:set" => { if let (Some(b), Some(g)) = (v.get("band").and_then(|x| x.as_u64()), v.get("gain").and_then(|x| x.as_f64())) { let _ = send(&ipc_writer, SOURCE, BridgeCommand::EqBand { band: b as usize, gain: g }); } }
                "module:open" => { if let Some(m) = v.get("module").and_then(|x| x.as_str()) { let _ = send(&ipc_writer, SOURCE, BridgeCommand::LaunchModule { module: m.to_string() }); } }
                "dialog:add-files" => {
                    if let Some(paths) = rfd::FileDialog::new().add_filter("Audio / Video / Tracker", &["mp3","wav","flac","ogg","m4a","aac","mod","it","xm","s3m","mp4","mkv","avi","mpg","mpeg","mov","webm"]).pick_files() {
                        let paths = paths.into_iter().map(|p| p.to_string_lossy().into_owned()).collect();
                        let _ = send(&ipc_writer, SOURCE, BridgeCommand::AddPaths { paths });
                    }
                }
                "dialog:add-folder" => {
                    if let Some(path) = rfd::FileDialog::new().pick_folder() {
                        let _ = send(&ipc_writer, SOURCE, BridgeCommand::AddFolder { path: path.to_string_lossy().into_owned() });
                    }
                }
                _ => {}
            }
        })
        .build(window.as_ref())
        .expect("webview");

    let (frame_tx, frame_rx) = mpsc::channel::<String>();
    let mut preview = match VideoPreview::new(frame_tx) {
        Ok(v) => Some(v),
        Err(e) => {
            let escaped = serde_json::to_string(&format!("VIDEO R4: {e}")).unwrap_or_else(|_| "\"VIDEO R4 error\"".into());
            let _ = webview.evaluate_script(&format!("window.MMP_VIDEO_CLEAR&&window.MMP_VIDEO_CLEAR({escaped});"));
            None
        }
    };

    let app_window = Arc::clone(&window);
    let _ = send(&writer, SOURCE, BridgeCommand::Status);
    event_loop.run(move |event, _, control_flow| {
        *control_flow = ControlFlow::WaitUntil(Instant::now() + Duration::from_millis(16));
        while let Ok(script) = ui_rx.try_recv() { let _ = webview.evaluate_script(&script); }
        while let Ok(state) = state_rx.try_recv() {
            if let Some(p) = preview.as_mut() {
                if let Err(e) = p.apply_snapshot(&state) {
                    let escaped = serde_json::to_string(&format!("VIDEO R4: {e}")).unwrap_or_else(|_| "\"VIDEO R4 error\"".into());
                    let _ = webview.evaluate_script(&format!("window.MMP_VIDEO_CLEAR&&window.MMP_VIDEO_CLEAR({escaped});"));
                } else if state.media_kind != "video" {
                    let _ = webview.evaluate_script("window.MMP_VIDEO_CLEAR&&window.MMP_VIDEO_CLEAR('Выберите видео в Playlist');");
                }
            }
        }
        while let Ok(frame) = frame_rx.try_recv() {
            let json = serde_json::to_string(&frame).unwrap_or_else(|_| "\"\"".into());
            let _ = webview.evaluate_script(&format!("window.MMP_VIDEO_FRAME&&window.MMP_VIDEO_FRAME({json});"));
        }

        if let Event::WindowEvent { event, .. } = event {
            match event {
                WindowEvent::Moved(p) => {
                    if !app_window.is_maximized() {
                        let z = app_window.scale_factor();
                        geom.x = (p.x as f64 / z).round() as i32;
                        geom.y = (p.y as f64 / z).round() as i32;
                        save_window_geometry("video", &geom);
                    }
                }
                WindowEvent::Resized(s) => {
                    if !app_window.is_maximized() {
                        let z = app_window.scale_factor();
                        geom.width = (s.width as f64 / z).round().max(1.0) as u32;
                        geom.height = (s.height as f64 / z).round().max(1.0) as u32;
                        save_window_geometry("video", &geom);
                    }
                }
                WindowEvent::CloseRequested | WindowEvent::Destroyed => {
                    save_window_geometry("video", &geom);
                    *control_flow = ControlFlow::Exit;
                }
                _ => {}
            }
        }
        if !app_window.is_visible() {
            save_window_geometry("video", &geom);
            *control_flow = ControlFlow::Exit;
        }
    });
}
