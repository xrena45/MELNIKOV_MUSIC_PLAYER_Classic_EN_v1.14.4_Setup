#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use std::{sync::{mpsc,Arc},time::{Duration,Instant}};
use melnikov_core::WindowGeometry;
use melnikov_ipc::{connect_or_start_bridge,read_server_loop,send,BridgeCommand};
use melnikov_platform::{default_geometry,load_window_geometry,save_window_geometry};
use tao::{dpi::{LogicalPosition,LogicalSize},event::{Event,WindowEvent},event_loop::{ControlFlow,EventLoop},window::WindowBuilder};
use wry::WebViewBuilder;
const MODULE_HTML:&str=include_str!("../assets/module.html");
const INIT_JS:&str=r####"(() => {
  const post = payload => { try { window.ipc?.postMessage(JSON.stringify(payload)); } catch (_) {} };
  const mmss = seconds => { if(!Number.isFinite(seconds)||seconds<0)seconds=0; const s=Math.floor(seconds); return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'); };
  const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fileUri = p => p ? 'file:///'+String(p).replace(/\\/g,'/').replace(/^\/+/, '') : '';
  const applyTheme = t => { document.body.classList.remove('theme-dark','theme-light'); if(t==='dark')document.body.classList.add('theme-dark'); if(t==='light')document.body.classList.add('theme-light'); document.querySelectorAll('.theme-choice').forEach(b=>b.classList.toggle('active',b.dataset.theme===t)); };
  window.MMP={post,mmss,esc,fileUri,applyTheme,state:null};
  window.MMP_BRIDGE={onMessage(message){if(message?.event==='state'){window.MMP.state=message.state;applyTheme(message.state.theme||'turquoise');window.dispatchEvent(new CustomEvent('mmp-state',{detail:message.state}));}if(message?.event==='error')window.dispatchEvent(new CustomEvent('mmp-error',{detail:message.message}));}};
  window.addEventListener('DOMContentLoaded',()=>{const drag=document.querySelector('.chrome,.whead,.vhead,.float-head');if(drag)drag.addEventListener('pointerdown',e=>{if(e.button===0&&!e.target.closest('button,.win,input,select'))post({cmd:'window:drag'});});post({cmd:'bridge:status'});});
})();

window.addEventListener('DOMContentLoaded',()=>{const {post}=MMP;const acts=[...document.querySelectorAll('.head-actions .headbtn')];if(acts[0])acts[0].onclick=()=>post({cmd:'window:minimize'});if(acts[1])acts[1].onclick=()=>post({cmd:'window:maximize-toggle'});if(acts[2])acts[2].onclick=()=>post({cmd:'window:close'});});
"####;
const SOURCE:&str="SUBSCRIPTION";
fn main(){
 let(writer,reader)=match connect_or_start_bridge(){Ok(v)=>v,Err(e)=>{eprintln!("MELNIKOV {SOURCE}: {e}");return;}};
 let event_loop=EventLoop::new();let(sw,sh)=event_loop.primary_monitor().map(|m|{let z=m.scale_factor();let s=m.size();(s.width as f64/z,s.height as f64/z)}).unwrap_or((1920.0,1080.0));
 let mut geom=load_window_geometry("subscription").unwrap_or_else(||default_geometry("subscription",sw,sh));
 let window=Arc::new(WindowBuilder::new().with_title("MELNIKOV MUSIC PLAYER — Subscription").with_inner_size(LogicalSize::new(geom.width as f64,geom.height as f64)).with_min_inner_size(LogicalSize::new(420.0,280.0)).with_position(LogicalPosition::new(geom.x as f64,geom.y as f64)).with_resizable(true).with_decorations(false).build(&event_loop).expect("window"));
 let(ui_tx,ui_rx)=mpsc::channel::<String>();read_server_loop(reader,move|message|{if let Ok(json)=serde_json::to_string(&message){let _=ui_tx.send(format!("window.MMP_BRIDGE&&window.MMP_BRIDGE.onMessage({json});"));}});
 let ipc_window=Arc::clone(&window);let ipc_writer=Arc::clone(&writer);
 let webview=WebViewBuilder::new().with_html(MODULE_HTML).with_initialization_script(INIT_JS).with_hotkeys_zoom(false).with_ipc_handler(move|request|{let body=request.body().as_str();let Ok(v)=serde_json::from_str::<serde_json::Value>(body)else{return};let cmd=v.get("cmd").and_then(|x|x.as_str()).unwrap_or("");match cmd{
 "window:minimize"=>ipc_window.set_minimized(true),"window:maximize-toggle"=>ipc_window.set_maximized(!ipc_window.is_maximized()),"window:drag"=>{let _=ipc_window.drag_window();},"window:close"=>ipc_window.set_visible(false),
 "bridge:status"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Status);},"media:play"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Play);},"media:pause"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Pause);},"media:toggle"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Toggle);},"media:stop"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Stop);},"media:previous"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Previous);},"media:next"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Next);},"media:clear"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Clear);},
 "media:seek-delta"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::SeekDelta{seconds:v.get("value").and_then(|x|x.as_f64()).unwrap_or(0.0)});},"media:seek-ratio"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::SeekRatio{ratio:v.get("value").and_then(|x|x.as_f64()).unwrap_or(0.0)});},"media:volume"=>{let _=send(&ipc_writer,SOURCE,BridgeCommand::Volume{value:v.get("value").and_then(|x|x.as_f64()).unwrap_or(0.75)});},"media:select"=>{if let Some(i)=v.get("index").and_then(|x|x.as_u64()){let _=send(&ipc_writer,SOURCE,BridgeCommand::Select{index:i as usize});}},"media:remove"=>{if let Some(i)=v.get("index").and_then(|x|x.as_u64()){let _=send(&ipc_writer,SOURCE,BridgeCommand::Remove{index:i as usize});}},
 "ui:theme"=>{if let Some(t)=v.get("value").and_then(|x|x.as_str()){let _=send(&ipc_writer,SOURCE,BridgeCommand::Theme{theme:t.to_string()});}},"eq:set"=>{if let(Some(b),Some(g))=(v.get("band").and_then(|x|x.as_u64()),v.get("gain").and_then(|x|x.as_f64())){let _=send(&ipc_writer,SOURCE,BridgeCommand::EqBand{band:b as usize,gain:g});}},"module:open"=>{if let Some(m)=v.get("module").and_then(|x|x.as_str()){let _=send(&ipc_writer,SOURCE,BridgeCommand::LaunchModule{module:m.to_string()});}},
 "dialog:add-files"=>{if let Some(paths)=rfd::FileDialog::new().add_filter("Audio / Video / Tracker",&["mp3","wav","flac","ogg","m4a","aac","mod","it","xm","s3m","mp4","mkv","avi","mpg","mpeg","mov","webm"]).pick_files(){let paths=paths.into_iter().map(|p|p.to_string_lossy().into_owned()).collect();let _=send(&ipc_writer,SOURCE,BridgeCommand::AddPaths{paths});}},"dialog:add-folder"=>{if let Some(path)=rfd::FileDialog::new().pick_folder(){let _=send(&ipc_writer,SOURCE,BridgeCommand::AddFolder{path:path.to_string_lossy().into_owned()});}},
 "system:open-url"=>{if let Some(url)=v.get("url").and_then(|x|x.as_str()){#[cfg(windows)]{let _=std::process::Command::new("cmd").args(["/C","start","",url]).spawn();}#[cfg(target_os="linux")]{let _=std::process::Command::new("xdg-open").arg(url).spawn();}}},_=>{}}}).build(window.as_ref()).expect("webview");
 let app_window=Arc::clone(&window);let _=send(&writer,SOURCE,BridgeCommand::Status);
 event_loop.run(move|event,_,control_flow|{*control_flow=ControlFlow::WaitUntil(Instant::now()+Duration::from_millis(16));while let Ok(script)=ui_rx.try_recv(){let _=webview.evaluate_script(&script);}if let Event::WindowEvent{event,..}=event{match event{WindowEvent::Moved(p)=>{if !app_window.is_maximized(){let z=app_window.scale_factor();geom.x=(p.x as f64/z).round() as i32;geom.y=(p.y as f64/z).round() as i32;save_window_geometry("subscription",&geom);}},WindowEvent::Resized(s)=>{if !app_window.is_maximized(){let z=app_window.scale_factor();geom.width=(s.width as f64/z).round().max(1.0) as u32;geom.height=(s.height as f64/z).round().max(1.0) as u32;save_window_geometry("subscription",&geom);}},WindowEvent::CloseRequested|WindowEvent::Destroyed=>{save_window_geometry("subscription",&geom);*control_flow=ControlFlow::Exit;},_=>{}}}if !app_window.is_visible(){save_window_geometry("subscription",&geom);*control_flow=ControlFlow::Exit;}});
}
