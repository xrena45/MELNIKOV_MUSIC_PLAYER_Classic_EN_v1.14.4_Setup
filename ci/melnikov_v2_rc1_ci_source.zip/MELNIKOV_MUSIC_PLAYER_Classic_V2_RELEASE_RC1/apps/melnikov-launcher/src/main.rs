#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use melnikov_ipc::{connect_or_start_bridge, send, BridgeCommand};
fn main(){
    if let Ok((writer,_reader))=connect_or_start_bridge(){
        let _=send(&writer,"LAUNCHER",BridgeCommand::LaunchModule{module:"player".to_string()});
    }
}
