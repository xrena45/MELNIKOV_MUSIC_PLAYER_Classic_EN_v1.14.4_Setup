#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::{
    collections::HashMap,
    io::{BufRead, BufReader, Write},
    net::{TcpListener, TcpStream},
    path::{Path, PathBuf},
    process::{Child, Command},
    sync::{mpsc, Arc, Mutex},
    thread,
    time::{Duration, Instant},
};

use melnikov_core::PlaybackState;
use melnikov_ipc::{
    apply_gstreamer_env, module_executable_name, BridgeCommand, ClientMessage, LyricLineSnapshot,
    PlayerSnapshot, PlaylistItemSnapshot, ServerMessage, BRIDGE_ADDR,
};
use melnikov_media::{
    gstreamer_backend::{EngineEvent, GStreamerEngine}, MediaEngine,
    AUDIO_EXTENSIONS, TRACKER_EXTENSIONS, VIDEO_EXTENSIONS,
};

struct PlayerBackend {
    engine: GStreamerEngine,
    playlist: Vec<PathBuf>,
    current: Option<usize>,
    playback: PlaybackState,
    volume: f32,
    theme: String,
    eq: [f32; 10],
    last_error: Option<String>,
}

impl PlayerBackend {
    fn new() -> Result<Self, String> {
        let mut engine = GStreamerEngine::new()?;
        engine.set_volume(0.75)?;
        Ok(Self { engine, playlist:Vec::new(), current:None, playback:PlaybackState::Stopped, volume:0.75, theme:"turquoise".into(), eq:[0.0;10], last_error:None })
    }
    fn ext(path:&Path)->String{path.extension().and_then(|e|e.to_str()).unwrap_or("").to_ascii_lowercase()}
    fn media_kind(path:&Path)->&'static str{let e=Self::ext(path);if VIDEO_EXTENSIONS.contains(&e.as_str()){"video"}else if TRACKER_EXTENSIONS.contains(&e.as_str()){"tracker"}else{"audio"}}
    fn is_supported(path:&Path)->bool{let e=Self::ext(path);AUDIO_EXTENSIONS.contains(&e.as_str())||TRACKER_EXTENSIONS.contains(&e.as_str())||VIDEO_EXTENSIONS.contains(&e.as_str())}
    fn add_paths<I:IntoIterator<Item=PathBuf>>(&mut self,paths:I){for path in paths{if !path.is_file()||!Self::is_supported(&path){continue}if !self.playlist.iter().any(|p|p==&path){self.playlist.push(path)}}if self.current.is_none()&&!self.playlist.is_empty(){self.current=Some(0);if let Err(e)=self.load_current(false){self.last_error=Some(e)}}}
    fn add_folder_recursive(&mut self,folder:PathBuf){fn walk(dir:&Path,out:&mut Vec<PathBuf>){let Ok(rd)=std::fs::read_dir(dir) else{return};for e in rd.flatten(){let p=e.path();if p.is_dir(){walk(&p,out)}else{out.push(p)}}}let mut files=Vec::new();walk(&folder,&mut files);files.retain(|p|Self::is_supported(p));files.sort_by_key(|p|p.to_string_lossy().to_lowercase());self.add_paths(files)}
    fn current_path(&self)->Option<&Path>{self.current.and_then(|i|self.playlist.get(i)).map(|p|p.as_path())}
    fn load_current(&mut self,autoplay:bool)->Result<(),String>{let p=self.current_path().ok_or("Playlist is empty")?.to_path_buf();self.engine.open_file(&p)?;self.engine.set_volume(self.volume)?;for(i,g)in self.eq.iter().enumerate(){let _=self.engine.set_eq_band(i,*g as f64);}self.last_error=None;if autoplay{self.engine.play()?;self.playback=PlaybackState::Playing}else{self.playback=PlaybackState::Stopped}Ok(())}
    fn play(&mut self)->Result<(),String>{if self.current.is_none(){if self.playlist.is_empty(){return Err("Добавьте аудио/видеофайл в Playlist".into())}self.current=Some(0);self.load_current(false)?}self.engine.play()?;self.playback=PlaybackState::Playing;self.last_error=None;Ok(())}
    fn pause(&mut self)->Result<(),String>{self.engine.pause()?;self.playback=PlaybackState::Paused;Ok(())}
    fn toggle(&mut self)->Result<(),String>{match self.playback{PlaybackState::Playing=>self.pause(),_=>self.play()}}
    fn stop(&mut self)->Result<(),String>{self.engine.stop()?;self.playback=PlaybackState::Stopped;Ok(())}
    fn select(&mut self,index:usize)->Result<(),String>{if index>=self.playlist.len(){return Err("Playlist index out of range".into())}self.current=Some(index);self.load_current(true)}
    fn remove(&mut self,index:usize)->Result<(),String>{if index>=self.playlist.len(){return Err("Playlist index out of range".into())}let was=self.current;self.playlist.remove(index);self.current=match(was,self.playlist.len()){(_,0)=>None,(Some(i),_) if i==index=>Some(index.min(self.playlist.len()-1)),(Some(i),_) if i>index=>Some(i-1),(v,_)=>v};if was==Some(index){if self.current.is_some(){self.load_current(true)?}else{let _=self.stop();}}Ok(())}
    fn next(&mut self)->Result<(),String>{if self.playlist.is_empty(){return Err("Playlist is empty".into())}self.current=Some(match self.current{Some(i)if i+1<self.playlist.len()=>i+1,_=>0});self.load_current(true)}
    fn previous(&mut self)->Result<(),String>{if self.playlist.is_empty(){return Err("Playlist is empty".into())}self.current=Some(match self.current{Some(i)if i>0=>i-1,_=>self.playlist.len()-1});self.load_current(true)}
    fn seek_delta(&mut self,d:f64)->Result<(),String>{let pos=self.engine.position_seconds();let dur=self.engine.duration_seconds();let mut t=(pos+d).max(0.0);if dur>0.0{t=t.min(dur)}self.engine.seek_seconds(t)}
    fn seek_ratio(&mut self,r:f64)->Result<(),String>{let d=self.engine.duration_seconds();if d>0.0{self.engine.seek_seconds(d*r.clamp(0.0,1.0))}else{Ok(())}}
    fn set_volume(&mut self,v:f64)->Result<(),String>{self.volume=v.clamp(0.0,1.0)as f32;self.engine.set_volume(self.volume)}
    fn set_theme(&mut self,t:String){if matches!(t.as_str(),"turquoise"|"dark"|"light"){self.theme=t}}
    fn set_eq(&mut self,band:usize,gain:f64)->Result<(),String>{if band>=10{return Err("EQ band out of range".into())}let g=gain.clamp(-24.0,12.0)as f32;self.eq[band]=g;self.engine.set_eq_band(band,g as f64)}
    fn clear(&mut self)->Result<(),String>{let _=self.engine.stop();self.playlist.clear();self.current=None;self.playback=PlaybackState::Stopped;self.last_error=None;Ok(())}
    fn poll(&mut self){if let Some(ev)=self.engine.poll_event(){match ev{EngineEvent::Eos=>{if !self.playlist.is_empty(){if let Err(e)=self.next(){self.last_error=Some(e)}}},EngineEvent::Error(e)=>{self.playback=PlaybackState::Stopped;self.last_error=Some(e)}}}}

    fn cover_for(path:&Path)->Option<String>{let dir=path.parent()?;for n in ["cover.jpg","cover.png","folder.jpg","folder.png","front.jpg","front.png"]{let p=dir.join(n);if p.is_file(){return Some(p.to_string_lossy().into_owned())}}None}
    fn lyrics_for(path:&Path)->Vec<LyricLineSnapshot>{let mut candidates=vec![path.with_extension("lrc"),path.with_extension("txt")];if let Some(dir)=path.parent(){candidates.push(dir.join("lyrics.lrc"));candidates.push(dir.join("lyrics.txt"));}let Some(p)=candidates.into_iter().find(|p|p.is_file())else{return Vec::new()};let Ok(s)=std::fs::read_to_string(p)else{return Vec::new()};let mut out=Vec::new();for line in s.lines(){let line=line.trim();if line.is_empty(){continue}if let Some(rest)=line.strip_prefix('['){if let Some(end)=rest.find(']'){let tag=&rest[..end];let text=rest[end+1..].trim();let mut it=tag.split(':');if let (Some(m),Some(sec))=(it.next(),it.next()){if let(Ok(m),Ok(sec))=(m.parse::<f64>(),sec.parse::<f64>()){out.push(LyricLineSnapshot{time:m*60.0+sec,text:text.to_string()});continue}}}}out.push(LyricLineSnapshot{time:-1.0,text:line.to_string()});}out}

    fn snapshot(&self)->PlayerSnapshot{
        let current_path=self.current_path().map(|p|p.to_string_lossy().into_owned());
        let current_title=self.current_path().and_then(|p|p.file_stem()).and_then(|s|s.to_str()).map(ToOwned::to_owned);
        let media_kind=self.current_path().map(Self::media_kind).unwrap_or("none").to_string();
        let playlist=self.playlist.iter().enumerate().map(|(index,path)|{let title=path.file_stem().and_then(|s|s.to_str()).unwrap_or("Unknown track").to_string();let e=Self::ext(path).to_ascii_uppercase();PlaylistItemSnapshot{index,title,path:path.to_string_lossy().into_owned(),source:format!("Local {e}"),media_kind:Self::media_kind(path).into()}}).collect();
        let sig=self.engine.signals();
        let cover_path=self.current_path().and_then(Self::cover_for);
        let lyrics=self.current_path().map(Self::lyrics_for).unwrap_or_default();
        PlayerSnapshot{playback:match self.playback{PlaybackState::Stopped=>"stopped",PlaybackState::Playing=>"playing",PlaybackState::Paused=>"paused"}.into(),volume:self.volume,position:self.engine.position_seconds(),duration:self.engine.duration_seconds(),current_index:self.current,current_title,current_path,media_kind,playlist,theme:self.theme.clone(),spectrum:self.engine.spectrum(),bass:sig.bass,mids:sig.mids,highs:sig.highs,energy:sig.energy,beat:sig.beat,onset:sig.onset,eq:self.eq.to_vec(),cover_path,lyrics,error:self.last_error.clone()}
    }
}

fn broadcast(clients:&Arc<Mutex<Vec<TcpStream>>>,message:&ServerMessage){let Ok(mut line)=serde_json::to_string(message)else{return};line.push('\n');if let Ok(mut list)=clients.lock(){list.retain_mut(|s|s.write_all(line.as_bytes()).and_then(|_|s.flush()).is_ok())}}
fn launch_module(module:&str,children:&mut HashMap<String,Child>)->Result<(),String>{if let Some(ch)=children.get_mut(module){if ch.try_wait().map_err(|e|e.to_string())?.is_none(){return Ok(())}}let exe=std::env::current_exe().map_err(|e|e.to_string())?;let dir=exe.parent().ok_or("Cannot resolve bridge directory")?;let target=dir.join(module_executable_name(module));if !target.is_file(){return Err(format!("Module executable not found: {}",target.display()))}let mut cmd=Command::new(&target);cmd.current_dir(dir);apply_gstreamer_env(&mut cmd);let child=cmd.spawn().map_err(|e|format!("Cannot launch {module}: {e}"))?;children.insert(module.to_string(),child);Ok(())}

fn main(){
    tracing_subscriber::fmt().with_env_filter(tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_|"warn".into())).init();
    let listener=match TcpListener::bind(BRIDGE_ADDR){Ok(v)=>v,Err(_)=>return};
    let clients:Arc<Mutex<Vec<TcpStream>>>=Arc::new(Mutex::new(Vec::new()));let(tx,rx)=mpsc::channel::<ClientMessage>();let accept_clients=Arc::clone(&clients);let accept_tx=tx.clone();
    thread::spawn(move||{for incoming in listener.incoming(){let Ok(stream)=incoming else{continue};let _=stream.set_nodelay(true);if let Ok(writer)=stream.try_clone(){if let Ok(mut list)=accept_clients.lock(){list.push(writer)}}let tx=accept_tx.clone();thread::spawn(move||{let reader=BufReader::new(stream);for line in reader.lines(){let Ok(line)=line else{break};if let Ok(msg)=serde_json::from_str::<ClientMessage>(&line){let _=tx.send(msg)}}});}});
    let mut backend=match PlayerBackend::new(){Ok(v)=>v,Err(e)=>{broadcast(&clients,&ServerMessage::Error{message:e});return}};let mut children:HashMap<String,Child>=HashMap::new();let mut last=Instant::now()-Duration::from_secs(1);
    broadcast(&clients,&ServerMessage::Hello{bridge:"MELNIKOV BRIDGE V2 RC1".into()});
    loop{
        match rx.recv_timeout(Duration::from_millis(25)){Ok(msg)=>{let result=match msg.command{BridgeCommand::Status=>Ok(()),BridgeCommand::Play=>backend.play(),BridgeCommand::Pause=>backend.pause(),BridgeCommand::Toggle=>backend.toggle(),BridgeCommand::Stop=>backend.stop(),BridgeCommand::Previous=>backend.previous(),BridgeCommand::Next=>backend.next(),BridgeCommand::SeekDelta{seconds}=>backend.seek_delta(seconds),BridgeCommand::SeekRatio{ratio}=>backend.seek_ratio(ratio),BridgeCommand::Volume{value}=>backend.set_volume(value),BridgeCommand::Select{index}=>backend.select(index),BridgeCommand::Remove{index}=>backend.remove(index),BridgeCommand::Clear=>backend.clear(),BridgeCommand::AddPaths{paths}=>{backend.add_paths(paths.into_iter().map(PathBuf::from));Ok(())},BridgeCommand::AddFolder{path}=>{backend.add_folder_recursive(PathBuf::from(path));Ok(())},BridgeCommand::Theme{theme}=>{backend.set_theme(theme);Ok(())},BridgeCommand::EqBand{band,gain}=>backend.set_eq(band,gain),BridgeCommand::LaunchModule{module}=>launch_module(&module,&mut children)};if let Err(e)=result{backend.last_error=Some(e)}broadcast(&clients,&ServerMessage::State{state:backend.snapshot()});last=Instant::now();},Err(mpsc::RecvTimeoutError::Timeout)=>{},Err(mpsc::RecvTimeoutError::Disconnected)=>break}
        backend.poll();if last.elapsed()>=Duration::from_millis(50){broadcast(&clients,&ServerMessage::State{state:backend.snapshot()});last=Instant::now()}children.retain(|_,c|c.try_wait().ok().flatten().is_none());
    }
}
