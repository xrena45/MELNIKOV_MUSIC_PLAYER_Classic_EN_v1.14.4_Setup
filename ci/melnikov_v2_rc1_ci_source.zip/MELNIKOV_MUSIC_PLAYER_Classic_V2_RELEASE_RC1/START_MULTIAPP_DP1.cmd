@echo off
cd /d "%~dp0"
start "" "melnikov-player.exe"
