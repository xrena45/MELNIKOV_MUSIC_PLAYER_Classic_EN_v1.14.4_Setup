# Phase 0 checklist

- [x] Workspace boundaries defined
- [x] Classic state types created
- [x] Default theme fixed to Turquoise
- [x] Default visualization fixed to Classic Spectrum Bars
- [x] Media format constants fixed
- [x] Network diagnostics model scaffolded
- [x] Platform abstraction scaffolded
- [x] Hospitality reserved as disabled feature
- [ ] Install Rust toolchain on build machine
- [ ] Run `cargo check -p melnikov-player`
- [ ] Run `cargo test -p melnikov-core`
- [ ] Commit bootstrap as release-development baseline
- [ ] Begin Phase 1 media MVP
