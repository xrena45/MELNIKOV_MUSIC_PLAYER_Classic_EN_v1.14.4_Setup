# Future Hospitality / Commercial Edition

This is a design reservation, not part of the Classic V2.0 release scope.

The Classic core should be reusable for:

- cafes
- restaurants
- hotels
- retail/public spaces
- scheduled background music
- external-display visualizations

Potential commercial modules:

1. Venue identity and device enrollment
2. Scheduled playback
3. Centrally managed playlists
4. Remote configuration and health checks
5. Commercial licensing state
6. Cloud delivery/cache
7. Zone/output routing
8. Visualization/signage mode on a connected display
9. Role-based administration
10. Audit/status logs

Rules:
- Classic local playback remains functional without these modules.
- Commercial services do not become hidden telemetry.
- Venue control endpoints are explicit and documented.
- A network outage must not stop already cached/local playback.
- Visualization can be launched in venue mode on the main or external display.
