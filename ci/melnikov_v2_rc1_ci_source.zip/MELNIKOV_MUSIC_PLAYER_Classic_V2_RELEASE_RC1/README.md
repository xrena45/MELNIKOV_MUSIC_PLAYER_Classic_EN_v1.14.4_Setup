# MELNIKOV MUSIC PLAYER Classic V2.0 — MULTIAPP DP1

Первый архитектурный переход V2 к отдельным приложениям, работающим в связке через MELNIKOV BRIDGE.

- UI-источник не перерисован: `approved_source/MELNIKOV_MUSIC_PLAYER_CLASSIC_V2_FINAL_RELEASE_CHECK.html`.
- Каждый модуль вынесен в отдельный Rust/Wry executable.
- Playback/GStreamer находится только в `melnikov-bridge`.
- Модули общаются с bridge по loopback TCP/JSON Lines.

Сборка на рабочей Windows-среде: `BUILD_MULTIAPP_DP1.cmd`.
