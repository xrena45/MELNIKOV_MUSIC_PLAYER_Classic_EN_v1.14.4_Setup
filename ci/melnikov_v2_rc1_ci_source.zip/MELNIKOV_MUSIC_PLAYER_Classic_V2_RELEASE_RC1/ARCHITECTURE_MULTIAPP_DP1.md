# MELNIKOV MUSIC PLAYER Classic V2.0 — MULTIAPP DP1

## Зафиксированная архитектура

```text
melnikov-player.exe ---------┐
melnikov-playlist.exe -------┤
melnikov-visualization.exe --┤
melnikov-video.exe ----------┤
melnikov-eq.exe -------------┤
melnikov-lyrics.exe ---------┤
melnikov-settings.exe -------┤
melnikov-cloud.exe ----------┤── TCP/JSON localhost ── melnikov-bridge.exe ── GStreamer
melnikov-cover.exe ----------┤                          (single playback state)
melnikov-subscription.exe ---┘
```

Каждый интерфейсный модуль — отдельный OS process и отдельное borderless WebView window.
HTML используется только как утверждённый визуальный/поведенческий источник конкретного модуля.
Ни Playlist, ни Visualization, ни Video не являются DIV внутри Player.

## Bridge

Loopback: `127.0.0.1:39462`.
Протокол: JSON Lines.

Bridge хранит единый playback state и GStreamer pipeline. Клиенты отправляют команды и получают
общий state snapshot. Это исключает несколько конкурирующих media engines.

## DP1 scope

Реально подключено к bridge:
- status;
- add files / folder;
- playlist state;
- select track;
- play / pause / toggle / stop;
- previous / next;
- seek delta / seek ratio;
- volume;
- EOS -> next;
- запуск отдельных модулей.

Следующие фазы: real FFT/visualizer stream, EQ DSP, Video sink, Lyrics, Cover, settings persistence.
