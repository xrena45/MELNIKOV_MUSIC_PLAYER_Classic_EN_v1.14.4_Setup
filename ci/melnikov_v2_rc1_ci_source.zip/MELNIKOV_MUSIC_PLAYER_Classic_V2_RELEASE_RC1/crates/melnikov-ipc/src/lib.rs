use serde::{Deserialize, Serialize};
use std::{
    io::{BufRead, BufReader, Write},
    net::{TcpStream, ToSocketAddrs},
    path::{Path, PathBuf},
    process::Command,
    sync::{Arc, Mutex},
    thread,
    time::Duration,
};

pub const BRIDGE_ADDR: &str = "127.0.0.1:39462";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "cmd", rename_all = "kebab-case")]
pub enum BridgeCommand {
    Status,
    Play,
    Pause,
    Toggle,
    Stop,
    Previous,
    Next,
    SeekDelta { seconds: f64 },
    SeekRatio { ratio: f64 },
    Volume { value: f64 },
    Select { index: usize },
    Remove { index: usize },
    Clear,
    AddPaths { paths: Vec<String> },
    AddFolder { path: String },
    Theme { theme: String },
    EqBand { band: usize, gain: f64 },
    LaunchModule { module: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClientMessage {
    pub source: String,
    #[serde(flatten)]
    pub command: BridgeCommand,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlaylistItemSnapshot {
    pub index: usize,
    pub title: String,
    pub path: String,
    pub source: String,
    pub media_kind: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LyricLineSnapshot {
    pub time: f64,
    pub text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlayerSnapshot {
    pub playback: String,
    pub volume: f32,
    pub position: f64,
    pub duration: f64,
    pub current_index: Option<usize>,
    pub current_title: Option<String>,
    pub current_path: Option<String>,
    pub media_kind: String,
    pub playlist: Vec<PlaylistItemSnapshot>,
    pub theme: String,
    pub spectrum: Vec<f32>,
    pub bass: f32,
    pub mids: f32,
    pub highs: f32,
    pub energy: f32,
    pub beat: f32,
    pub onset: f32,
    pub eq: Vec<f32>,
    pub cover_path: Option<String>,
    pub lyrics: Vec<LyricLineSnapshot>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "event", rename_all = "kebab-case")]
pub enum ServerMessage {
    State { state: PlayerSnapshot },
    Error { message: String },
    Hello { bridge: String },
}

pub type SharedWriter = Arc<Mutex<TcpStream>>;

pub fn send(writer: &SharedWriter, source: &str, command: BridgeCommand) -> Result<(), String> {
    let msg = ClientMessage { source: source.to_string(), command };
    let mut json = serde_json::to_string(&msg).map_err(|e| e.to_string())?;
    json.push('\n');
    let mut stream = writer.lock().map_err(|_| "bridge writer poisoned".to_string())?;
    stream.write_all(json.as_bytes()).map_err(|e| e.to_string())?;
    stream.flush().map_err(|e| e.to_string())
}

fn try_connect() -> std::io::Result<TcpStream> {
    let addr = BRIDGE_ADDR.to_socket_addrs()?.next().ok_or_else(|| std::io::Error::other("invalid bridge address"))?;
    let stream = TcpStream::connect_timeout(&addr, Duration::from_millis(250))?;
    stream.set_nodelay(true)?;
    Ok(stream)
}

pub fn candidate_gstreamer_roots() -> Vec<PathBuf> {
    let mut roots = Vec::new();
    for key in ["GSTREAMER_1_0_ROOT_MSVC_X86_64", "GSTREAMER_1_0_ROOT_X86_64"] {
        if let Some(v) = std::env::var_os(key) { roots.push(PathBuf::from(v)); }
    }
    if let Some(local) = std::env::var_os("LOCALAPPDATA") {
        roots.push(PathBuf::from(local).join("Programs").join("gstreamer").join("1.0").join("msvc_x86_64"));
    }
    roots.push(PathBuf::from(r"C:\Program Files\gstreamer\1.0\msvc_x86_64"));
    roots.push(PathBuf::from(r"C:\gstreamer\1.0\msvc_x86_64"));
    roots
}

pub fn apply_gstreamer_env(cmd: &mut Command) {
    #[cfg(windows)] {
        if let Some(root) = candidate_gstreamer_roots().into_iter().find(|p| p.join("bin").is_dir()) {
            let bin = root.join("bin");
            let plugins = root.join("lib").join("gstreamer-1.0");
            let current = std::env::var_os("PATH").unwrap_or_default();
            let mut parts = vec![bin];
            parts.extend(std::env::split_paths(&current));
            if let Ok(joined) = std::env::join_paths(parts) { cmd.env("PATH", joined); }
            if plugins.is_dir() {
                cmd.env("GST_PLUGIN_PATH", &plugins);
                cmd.env("GST_PLUGIN_SYSTEM_PATH", &plugins);
            }
        }
    }
}

pub fn connect_or_start_bridge() -> Result<(SharedWriter, TcpStream), String> {
    if let Ok(stream) = try_connect() {
        let reader = stream.try_clone().map_err(|e| e.to_string())?;
        return Ok((Arc::new(Mutex::new(stream)), reader));
    }
    let exe = std::env::current_exe().map_err(|e| e.to_string())?;
    let dir = exe.parent().ok_or_else(|| "cannot resolve executable directory".to_string())?;
    let bridge = dir.join(module_executable_name("bridge"));
    if !bridge.is_file() { return Err(format!("Bridge executable not found: {}", bridge.display())); }
    let mut cmd = Command::new(&bridge);
    cmd.current_dir(dir);
    apply_gstreamer_env(&mut cmd);
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        cmd.creation_flags(CREATE_NO_WINDOW);
    }
    cmd.spawn().map_err(|e| format!("cannot start bridge: {e}"))?;
    for _ in 0..50 {
        thread::sleep(Duration::from_millis(100));
        if let Ok(stream) = try_connect() {
            let reader = stream.try_clone().map_err(|e| e.to_string())?;
            return Ok((Arc::new(Mutex::new(stream)), reader));
        }
    }
    Err("MELNIKOV BRIDGE did not start".to_string())
}

pub fn read_server_loop<F>(stream: TcpStream, mut on_message: F)
where F: FnMut(ServerMessage) + Send + 'static {
    thread::spawn(move || {
        let reader = BufReader::new(stream);
        for line in reader.lines() {
            let Ok(line) = line else { break };
            if let Ok(message) = serde_json::from_str::<ServerMessage>(&line) { on_message(message); }
        }
    });
}

pub fn module_executable_name(module: &str) -> String {
    if cfg!(windows) { format!("melnikov-{module}.exe") } else { format!("melnikov-{module}") }
}

pub fn sibling_module_path(module: &str) -> Result<PathBuf, String> {
    let exe = std::env::current_exe().map_err(|e| e.to_string())?;
    let dir = exe.parent().ok_or_else(|| "cannot resolve executable directory".to_string())?;
    Ok(dir.join(module_executable_name(module)))
}

pub fn spawn_sibling(module: &str) -> Result<(), String> {
    let path = sibling_module_path(module)?;
    if !path.is_file() { return Err(format!("Module executable not found: {}", path.display())); }
    let dir = path.parent().unwrap_or_else(|| Path::new("."));
    let mut cmd = Command::new(&path);
    cmd.current_dir(dir);
    apply_gstreamer_env(&mut cmd);
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        if module == "bridge" { cmd.creation_flags(CREATE_NO_WINDOW); }
    }
    cmd.spawn().map(|_| ()).map_err(|e| format!("Cannot launch {module}: {e}"))
}
