pub const EQ_BANDS_HZ: [u32; 10] = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

#[derive(Debug, Clone)]
pub struct EqualizerState {
    pub enabled: bool,
    pub gains_db: [f32; 10],
}

impl Default for EqualizerState {
    fn default() -> Self {
        Self {
            enabled: true,
            gains_db: [0.0; 10],
        }
    }
}

#[derive(Debug, Clone)]
pub struct SpectrumFrame {
    pub bins: Vec<f32>,
}

impl SpectrumFrame {
    pub fn silence(bin_count: usize) -> Self {
        Self { bins: vec![0.0; bin_count] }
    }
}
