use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Theme {
    Turquoise,
    Dark,
    Light,
}

impl Default for Theme {
    fn default() -> Self {
        Self::Turquoise
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PlaybackState {
    Stopped,
    Playing,
    Paused,
}

impl Default for PlaybackState {
    fn default() -> Self {
        Self::Stopped
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WindowGeometry {
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
    pub fullscreen: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppState {
    pub theme: Theme,
    pub playback: PlaybackState,
    pub volume: f32,
    pub main_window: WindowGeometry,
}

impl Default for AppState {
    fn default() -> Self {
        Self {
            theme: Theme::Turquoise,
            playback: PlaybackState::Stopped,
            volume: 0.75,
            main_window: WindowGeometry {
                x: 100,
                y: 100,
                width: 1100,
                height: 760,
                fullscreen: false,
            },
        }
    }
}

impl AppState {
    pub fn set_volume(&mut self, value: f32) {
        self.volume = value.clamp(0.0, 1.0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn volume_is_clamped() {
        let mut state = AppState::default();
        state.set_volume(2.0);
        assert_eq!(state.volume, 1.0);
        state.set_volume(-1.0);
        assert_eq!(state.volume, 0.0);
    }
}
