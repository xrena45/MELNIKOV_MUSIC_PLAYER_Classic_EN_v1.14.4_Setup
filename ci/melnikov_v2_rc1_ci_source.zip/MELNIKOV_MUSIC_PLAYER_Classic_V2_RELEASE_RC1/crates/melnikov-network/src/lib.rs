use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CheckStatus {
    Ok,
    Offline,
    NotConfigured,
    AuthRequired,
    Timeout,
    DnsError,
    TlsError,
    ServiceUnavailable,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiagnosticItem {
    pub name: String,
    pub status: CheckStatus,
    pub detail: Option<String>,
}

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct NetworkDiagnostics {
    pub checks: Vec<DiagnosticItem>,
}

impl NetworkDiagnostics {
    pub fn sanitized_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }
}

// Future HTTP client requirements:
// - explicit rustls TLS
// - bounded timeout
// - bounded retry with backoff + jitter
// - cancellation
// - never block playback/UI
// - no secrets in diagnostics/logs
