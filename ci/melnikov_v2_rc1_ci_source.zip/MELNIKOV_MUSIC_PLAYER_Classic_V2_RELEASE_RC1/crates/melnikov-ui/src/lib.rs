pub const APPROVED_SUBTITLE: &str =
    "Система музыкального обслуживания общественных пространств";

pub const FORMAT_HEADER: &str = "MOD / IT / XM / S3M support";

// Phase 2 will port the approved FINAL RELEASE CHECK HTML into Slint.
// No redesign is permitted during that port.
