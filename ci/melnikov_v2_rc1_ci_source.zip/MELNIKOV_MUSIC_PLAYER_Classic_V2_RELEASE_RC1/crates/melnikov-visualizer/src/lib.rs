use melnikov_dsp::SpectrumFrame;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VisualizerPreset {
    ClassicSpectrumBars,
    ColorSpectrum,
    MirrorSpectrum,
    WaveLissajous,
    MelnikovNeon,
}

impl Default for VisualizerPreset {
    fn default() -> Self {
        Self::ClassicSpectrumBars
    }
}

#[derive(Debug, Default)]
pub struct VisualizerState {
    pub preset: VisualizerPreset,
}

impl VisualizerState {
    pub fn consume(&mut self, _frame: &SpectrumFrame) {
        // Rendering comes in Phase 3.
        // Keep spectrum consumption independent from window drag/resize.
    }
}
