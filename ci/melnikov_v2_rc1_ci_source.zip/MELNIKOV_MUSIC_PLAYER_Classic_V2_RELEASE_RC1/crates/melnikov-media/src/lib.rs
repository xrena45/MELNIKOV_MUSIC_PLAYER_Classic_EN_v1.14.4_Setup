#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MediaKind { Audio, Video, Image, AudioCd, TrackerModule }
pub const AUDIO_EXTENSIONS:&[&str]=&["mp3","wav","flac","ogg","m4a","aac"];
pub const TRACKER_EXTENSIONS:&[&str]=&["mod","it","xm","s3m"];
pub const VIDEO_EXTENSIONS:&[&str]=&["mp4","mkv","avi","mpg","mpeg","mov","webm"];
pub trait MediaEngine:Send{fn play(&mut self)->Result<(),String>;fn pause(&mut self)->Result<(),String>;fn stop(&mut self)->Result<(),String>;fn seek_seconds(&mut self,seconds:f64)->Result<(),String>;fn set_volume(&mut self,volume:f32)->Result<(),String>;}
#[cfg(feature="gstreamer-backend")] pub mod gstreamer_backend;
