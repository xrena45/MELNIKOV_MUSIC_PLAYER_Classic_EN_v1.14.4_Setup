use std::{path::Path, time::Instant};
use gstreamer as gst;
use gst::prelude::*;
use url::Url;
use crate::MediaEngine;

#[derive(Debug, Clone)]
pub enum EngineEvent { Eos, Error(String) }

#[derive(Debug, Clone, Copy, Default)]
pub struct AudioSignals {
    pub bass: f32, pub mids: f32, pub highs: f32, pub energy: f32, pub beat: f32, pub onset: f32,
}

pub struct GStreamerEngine {
    playbin: gst::Pipeline,
    equalizer: gst::Element,
    spectrum_values: Vec<f32>,
    signals: AudioSignals,
    bass_floor: f32,
    prev_bass: f32,
    last_beat: Instant,
}

fn db_norm(db: f32) -> f32 { ((db + 80.0) / 80.0).clamp(0.0, 1.0).powf(1.35) }
fn avg(v:&[f32], a:usize, b:usize)->f32 { let end=b.min(v.len()); let start=a.min(end); if start==end {0.0} else {v[start..end].iter().copied().sum::<f32>()/(end-start) as f32} }

impl GStreamerEngine {
    pub fn new() -> Result<Self, String> {
        gst::init().map_err(|err| format!("GStreamer init failed: {err}"))?;
        let element = gst::ElementFactory::make("playbin3").build().map_err(|err| format!("Could not create playbin3: {err}"))?;
        let playbin = element.downcast::<gst::Pipeline>().map_err(|_| "playbin3 is not a GstPipeline".to_string())?;

        let equalizer = gst::ElementFactory::make("equalizer-10bands").build().map_err(|e| format!("equalizer-10bands unavailable: {e}"))?;
        let spectrum = gst::ElementFactory::make("spectrum")
            .property("bands", 96_u32).property("threshold", -80_i32)
            .property("post-messages", true).property("message-magnitude", true)
            .property("message-phase", false).property("interval", 25_000_000_u64)
            .build().map_err(|e| format!("spectrum unavailable: {e}"))?;
        let bin = gst::Bin::new();
        bin.add_many([&equalizer, &spectrum]).map_err(|e| e.to_string())?;
        equalizer.link(&spectrum).map_err(|e| e.to_string())?;
        let sink_target = equalizer.static_pad("sink").ok_or("equalizer sink pad unavailable")?;
        let src_target = spectrum.static_pad("src").ok_or("spectrum src pad unavailable")?;
        let sink_ghost = gst::GhostPad::builder_with_target(&sink_target).map_err(|e| e.to_string())?.name("sink").build();
        let src_ghost = gst::GhostPad::builder_with_target(&src_target).map_err(|e| e.to_string())?.name("src").build();
        sink_ghost.set_active(true).map_err(|e| e.to_string())?;
        src_ghost.set_active(true).map_err(|e| e.to_string())?;
        bin.add_pad(&sink_ghost).map_err(|e| e.to_string())?;
        bin.add_pad(&src_ghost).map_err(|e| e.to_string())?;
        playbin.set_property("audio-filter", &bin);

        Ok(Self { playbin, equalizer, spectrum_values: vec![0.0;28], signals:AudioSignals::default(), bass_floor:0.0, prev_bass:0.0, last_beat:Instant::now()-std::time::Duration::from_secs(1) })
    }

    pub fn open_file<P: AsRef<Path>>(&mut self, path: P) -> Result<(), String> {
        let path = std::fs::canonicalize(path.as_ref()).map_err(|err| format!("Could not resolve media path: {err}"))?;
        let uri = Url::from_file_path(&path).map_err(|_| format!("Could not convert path to file URI: {}", path.display()))?;
        self.playbin.set_state(gst::State::Null).map_err(|err| format!("Could not reset pipeline: {err:?}"))?;
        self.playbin.set_property("uri", uri.as_str());
        self.spectrum_values.fill(0.0); self.signals=AudioSignals::default(); self.bass_floor=0.0; self.prev_bass=0.0;
        Ok(())
    }

    pub fn position_seconds(&self) -> f64 { self.playbin.query_position::<gst::ClockTime>().map(|v|v.nseconds() as f64/1e9).unwrap_or(0.0) }
    pub fn duration_seconds(&self) -> f64 { self.playbin.query_duration::<gst::ClockTime>().map(|v|v.nseconds() as f64/1e9).unwrap_or(0.0) }
    pub fn spectrum(&self)->Vec<f32>{self.spectrum_values.clone()}
    pub fn signals(&self)->AudioSignals{self.signals}
    pub fn set_eq_band(&self, band:usize, gain:f64)->Result<(),String>{ if band>=10{return Err("EQ band out of range".into())}; self.equalizer.set_property(&format!("band{band}"), gain.clamp(-24.0,12.0)); Ok(()) }

    pub fn poll_event(&mut self) -> Option<EngineEvent> {
        let bus = self.playbin.bus()?;
        while let Some(message) = bus.pop() {
            match message.view() {
                gst::MessageView::Element(element) => {
                    let Some(s)=element.structure() else {continue};
                    if s.name()!="spectrum" {continue}
                    let Ok(list)=s.get::<gst::ListRef>("magnitude") else {continue};
                    let mut vals=Vec::with_capacity(list.len());
                    for v in list.iter(){ if let Ok(db)=v.get::<f32>(){vals.push(db_norm(db));} }
                    if vals.is_empty(){continue}
                    // 28 display bars from the full 96-bin analyzer.
                    let mut bars=Vec::with_capacity(28);
                    for i in 0..28 { let a=i*vals.len()/28; let b=((i+1)*vals.len()/28).max(a+1); bars.push(avg(&vals,a,b)); }
                    self.spectrum_values=bars;
                    let bass=avg(&vals,0,10); let mids=avg(&vals,10,40); let highs=avg(&vals,40,vals.len());
                    let energy=(bass*0.46+mids*0.36+highs*0.18).clamp(0.0,1.0);
                    self.bass_floor=self.bass_floor*0.965+bass*0.035;
                    let onset=(bass-self.prev_bass).max(0.0); self.prev_bass=bass;
                    self.signals.beat*=0.80; self.signals.onset*=0.72;
                    let now=Instant::now(); let threshold=self.bass_floor+0.045+self.bass_floor*0.22;
                    if now.duration_since(self.last_beat)>=std::time::Duration::from_millis(185) && bass>threshold && onset>0.015 {
                        self.signals.beat=1.0; self.signals.onset=(0.55+onset*7.0).clamp(0.0,1.0); self.last_beat=now;
                    } else { self.signals.onset=self.signals.onset.max((onset*4.0).clamp(0.0,0.65)); }
                    let smooth=|old:f32,new:f32| old+(new-old)*if new>old{0.48}else{0.11};
                    self.signals.bass=smooth(self.signals.bass,bass); self.signals.mids=smooth(self.signals.mids,mids); self.signals.highs=smooth(self.signals.highs,highs); self.signals.energy=smooth(self.signals.energy,energy);
                }
                gst::MessageView::Eos(..)=>return Some(EngineEvent::Eos),
                gst::MessageView::Error(err)=>{ let src=message.src().map(|s|s.path_string().to_string()).unwrap_or_else(||"unknown".into()); let dbg=err.debug().unwrap_or_else(||"no debug details".into()); return Some(EngineEvent::Error(format!("GStreamer error from {src}: {} | {dbg}",err.error()))); }
                _=>{}
            }
        }
        None
    }
}

impl MediaEngine for GStreamerEngine {
    fn play(&mut self)->Result<(),String>{self.playbin.set_state(gst::State::Playing).map_err(|e|format!("Could not start playback: {e:?}"))?;Ok(())}
    fn pause(&mut self)->Result<(),String>{self.playbin.set_state(gst::State::Paused).map_err(|e|format!("Could not pause playback: {e:?}"))?;Ok(())}
    fn stop(&mut self)->Result<(),String>{self.playbin.set_state(gst::State::Null).map_err(|e|format!("Could not stop playback: {e:?}"))?;Ok(())}
    fn seek_seconds(&mut self,seconds:f64)->Result<(),String>{ if !seconds.is_finite()||seconds<0.0{return Err("Seek position must be finite and non-negative".into())}; let nanos=(seconds*1e9).round() as u64; self.playbin.seek_simple(gst::SeekFlags::FLUSH|gst::SeekFlags::KEY_UNIT,gst::ClockTime::from_nseconds(nanos)).map_err(|e|format!("Seek failed: {e}"))?;Ok(())}
    fn set_volume(&mut self,volume:f32)->Result<(),String>{self.playbin.set_property("volume",volume.clamp(0.0,1.0) as f64);Ok(())}
}
impl Drop for GStreamerEngine{fn drop(&mut self){let _=self.playbin.set_state(gst::State::Null);}}
