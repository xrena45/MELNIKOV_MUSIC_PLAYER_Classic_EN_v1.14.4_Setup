use melnikov_core::WindowGeometry;
use std::path::PathBuf;

fn config_dir() -> PathBuf {
    #[cfg(windows)] {
        if let Some(v)=std::env::var_os("APPDATA") { return PathBuf::from(v).join("MELNIKOV MUSIC PLAYER Classic V2"); }
    }
    #[cfg(not(windows))] {
        if let Some(v)=std::env::var_os("XDG_CONFIG_HOME") { return PathBuf::from(v).join("melnikov-music-player-v2"); }
        if let Some(v)=std::env::var_os("HOME") { return PathBuf::from(v).join(".config").join("melnikov-music-player-v2"); }
    }
    std::env::temp_dir().join("melnikov-music-player-v2")
}

pub fn load_window_geometry(module:&str)->Option<WindowGeometry>{let p=config_dir().join(format!("window-{module}.json"));let b=std::fs::read(p).ok()?;serde_json::from_slice(&b).ok()}
pub fn save_window_geometry(module:&str,g:&WindowGeometry){let dir=config_dir();let _=std::fs::create_dir_all(&dir);if let Ok(b)=serde_json::to_vec_pretty(g){let _=std::fs::write(dir.join(format!("window-{module}.json")),b);}}

pub fn default_geometry(module:&str,screen_w:f64,screen_h:f64)->WindowGeometry{
    let (w,h)=match module{"player"=>(1108.0,680.0),"playlist"|"visualization"=>(509.0,270.0),"video"=>(900.0,620.0),"eq"|"lyrics"|"settings"|"cloud"|"cover"|"subscription"=>(620.0,430.0),_=>(620.0,430.0)};
    let player_x=((screen_w-1108.0)/2.0).max(10.0);let player_y=20.0;
    let (x,y)=match module{
        "player"=>(player_x,player_y),
        "playlist"=>(player_x,(player_y+680.0+12.0).min((screen_h-h-10.0).max(10.0))),
        "visualization"=>(player_x+521.0,(player_y+680.0+12.0).min((screen_h-h-10.0).max(10.0))),
        _=>(((screen_w-w)/2.0).max(10.0),((screen_h-h)/2.0).max(10.0)),
    };
    WindowGeometry{x:x.round() as i32,y:y.round() as i32,width:w as u32,height:h as u32,fullscreen:false}
}
