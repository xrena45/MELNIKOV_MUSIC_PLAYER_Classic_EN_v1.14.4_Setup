use melnikov_core::WindowGeometry;
use std::path::PathBuf;

fn config_dir() -> PathBuf {
    #[cfg(windows)] {
        if let Some(v)=std::env::var_os("APPDATA") { return PathBuf::from(v).join("MELNIKOV MUSIC PLAYER Classic V2.0"); }
    }
    #[cfg(not(windows))] {
        if let Some(v)=std::env::var_os("XDG_CONFIG_HOME") { return PathBuf::from(v).join("melnikov-music-player-v2.0"); }
        if let Some(v)=std::env::var_os("HOME") { return PathBuf::from(v).join(".config").join("melnikov-music-player-v2.0"); }
    }
    std::env::temp_dir().join("melnikov-music-player-v2.0")
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlayerPreferences {
    pub theme: String,
    pub volume: f32,
    pub eq: Vec<f32>,
}

impl Default for PlayerPreferences {
    fn default() -> Self {
        Self { theme: "turquoise".into(), volume: 0.75, eq: vec![0.0; 10] }
    }
}

pub fn load_player_preferences() -> PlayerPreferences {
    let p = config_dir().join("player-preferences.json");
    let Ok(bytes) = std::fs::read(p) else { return PlayerPreferences::default(); };
    let Ok(mut prefs) = serde_json::from_slice::<PlayerPreferences>(&bytes) else { return PlayerPreferences::default(); };
    if !matches!(prefs.theme.as_str(), "turquoise" | "dark" | "light") { prefs.theme = "turquoise".into(); }
    prefs.volume = prefs.volume.clamp(0.0, 1.0);
    prefs.eq.resize(10, 0.0);
    prefs.eq.truncate(10);
    for gain in &mut prefs.eq { *gain = gain.clamp(-24.0, 12.0); }
    prefs
}

pub fn save_player_preferences(prefs: &PlayerPreferences) {
    let dir = config_dir();
    let _ = std::fs::create_dir_all(&dir);
    if let Ok(bytes) = serde_json::to_vec_pretty(prefs) {
        let tmp = dir.join("player-preferences.json.tmp");
        let dst = dir.join("player-preferences.json");
        if std::fs::write(&tmp, bytes).is_ok() {
            let _ = std::fs::remove_file(&dst);
            let _ = std::fs::rename(tmp, dst);
        }
    }
}

pub fn load_window_geometry(module:&str)->Option<WindowGeometry>{let p=config_dir().join(format!("window-{module}.json"));let b=std::fs::read(p).ok()?;serde_json::from_slice(&b).ok()}
pub fn save_window_geometry(module:&str,g:&WindowGeometry){let dir=config_dir();let _=std::fs::create_dir_all(&dir);if let Ok(b)=serde_json::to_vec_pretty(g){let _=std::fs::write(dir.join(format!("window-{module}.json")),b);}}

pub fn default_geometry(module:&str,screen_w:f64,screen_h:f64)->WindowGeometry{
    let (w,h)=match module{"player"=>(1108.0,680.0),"playlist"|"visualization"=>(509.0,270.0),"video"=>(900.0,620.0),"eq"|"lyrics"|"settings"|"cloud"|"cover"|"subscription"=>(620.0,430.0),_=>(620.0,430.0)};
    let player_x=((screen_w-1108.0)/2.0).max(10.0);let player_y=20.0;
    let (x,y)=match module{
        "player"=>(player_x,player_y),
        "playlist"=>(player_x,(player_y+680.0+12.0).min((screen_h-h-10.0).max(10.0))),
        "visualization"=>(player_x+521.0,(player_y+680.0+12.0).min((screen_h-h-10.0).max(10.0))),
        _=>(((screen_w-w)/2.0).max(10.0),((screen_h-h)/2.0).max(10.0)),
    };
    WindowGeometry{x:x.round() as i32,y:y.round() as i32,width:w as u32,height:h as u32,fullscreen:false}
}
