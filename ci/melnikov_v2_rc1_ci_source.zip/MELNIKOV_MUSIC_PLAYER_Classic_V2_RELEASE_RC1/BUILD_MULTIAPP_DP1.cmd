@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo  MELNIKOV MUSIC PLAYER Classic V2.0 - MULTIAPP DP1 FIX1
echo  Separate EXE modules + MELNIKOV BRIDGE
echo  GStreamer build environment auto-detection
echo ============================================================
echo.

where cargo >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Rust/Cargo not found in PATH.
  pause
  exit /b 1
)

set "GST_ROOT=C:\Program Files\gstreamer\1.0\msvc_x86_64"
set "GST_BIN=%GST_ROOT%\bin"
set "GST_LIB=%GST_ROOT%\lib"
set "GST_PKG=%GST_ROOT%\lib\pkgconfig"
set "GST_SHARE_PKG=%GST_ROOT%\share\pkgconfig"

if not exist "%GST_BIN%\gstreamer-1.0-0.dll" (
  echo [ERROR] GStreamer MSVC x86_64 not found:
  echo %GST_ROOT%
  pause
  exit /b 1
)

echo [OK] GStreamer runtime found.

rem The successful V2 Phase-1 GStreamer test used the GStreamer BIN directory
rem in PATH before Cargo was invoked. Do the same here for glib/gstreamer-sys.
set "PATH=%GST_BIN%;%PATH%"
set "GSTREAMER_1_0_ROOT_MSVC_X86_64=%GST_ROOT%"
set "GSTREAMER_1_0_ROOT_X86_64=%GST_ROOT%"
set "PKG_CONFIG_PATH=%GST_PKG%;%GST_SHARE_PKG%"
set "PKG_CONFIG_ALLOW_SYSTEM_CFLAGS=1"
set "PKG_CONFIG_ALLOW_SYSTEM_LIBS=1"

rem pkg-config is normally shipped with the GStreamer MSVC development package.
rem First try PATH, then search inside the known GStreamer root.
set "PKG_CONFIG_EXE="
for /f "delims=" %%P in ('where pkg-config.exe 2^>nul') do if not defined PKG_CONFIG_EXE set "PKG_CONFIG_EXE=%%P"
if not defined PKG_CONFIG_EXE (
  for /r "%GST_ROOT%" %%P in (pkg-config.exe) do if not defined PKG_CONFIG_EXE set "PKG_CONFIG_EXE=%%P"
)
if not defined PKG_CONFIG_EXE (
  for /f "delims=" %%P in ('where pkgconf.exe 2^>nul') do if not defined PKG_CONFIG_EXE set "PKG_CONFIG_EXE=%%P"
)
if not defined PKG_CONFIG_EXE (
  for /r "%GST_ROOT%" %%P in (pkgconf.exe) do if not defined PKG_CONFIG_EXE set "PKG_CONFIG_EXE=%%P"
)

if not defined PKG_CONFIG_EXE (
  echo.
  echo [ERROR] pkg-config.exe was not found inside the installed GStreamer SDK.
  echo Expected GStreamer development tools under:
  echo %GST_ROOT%
  echo.
  echo No source code needs manual editing.
  pause
  exit /b 1
)

set "PKG_CONFIG=%PKG_CONFIG_EXE%"
for %%D in ("%PKG_CONFIG_EXE%") do set "PATH=%%~dpD;%PATH%"
echo [OK] pkg-config: %PKG_CONFIG_EXE%

"%PKG_CONFIG_EXE%" --version >nul 2>nul
if errorlevel 1 (
  echo [ERROR] pkg-config exists but cannot be executed.
  pause
  exit /b 1
)

"%PKG_CONFIG_EXE%" --modversion glib-2.0 >nul 2>nul
if errorlevel 1 (
  echo [ERROR] pkg-config cannot resolve glib-2.0.
  echo PKG_CONFIG_PATH=%PKG_CONFIG_PATH%
  pause
  exit /b 1
)

echo [OK] glib-2.0 detected.

"%PKG_CONFIG_EXE%" --modversion gstreamer-1.0 >nul 2>nul
if errorlevel 1 (
  echo [ERROR] pkg-config cannot resolve gstreamer-1.0.
  echo PKG_CONFIG_PATH=%PKG_CONFIG_PATH%
  pause
  exit /b 1
)

echo [OK] gstreamer-1.0 detected.

taskkill /IM melnikov-bridge.exe /F >nul 2>nul
taskkill /IM melnikov-player.exe /F >nul 2>nul
taskkill /IM melnikov-playlist.exe /F >nul 2>nul
taskkill /IM melnikov-visualization.exe /F >nul 2>nul

echo.
echo [1/2] Building independent V2 applications...
cargo build --release ^
  -p melnikov-bridge ^
  -p melnikov-player ^
  -p melnikov-playlist ^
  -p melnikov-visualization ^
  -p melnikov-video ^
  -p melnikov-eq ^
  -p melnikov-lyrics ^
  -p melnikov-settings ^
  -p melnikov-cloud ^
  -p melnikov-cover ^
  -p melnikov-subscription
if errorlevel 1 (
  echo.
  echo [BUILD FAILED]
  pause
  exit /b 1
)

echo.
echo [2/2] Preparing DIST...
if exist DIST rmdir /S /Q DIST
mkdir DIST
for %%F in (melnikov-bridge melnikov-player melnikov-playlist melnikov-visualization melnikov-video melnikov-eq melnikov-lyrics melnikov-settings melnikov-cloud melnikov-cover melnikov-subscription) do (
  copy /Y "target\release\%%F.exe" "DIST\%%F.exe" >nul
)
copy /Y "START_MULTIAPP_DP1.cmd" "DIST\START_MULTIAPP_DP1.cmd" >nul
copy /Y "README_DP1_RU.txt" "DIST\README_DP1_RU.txt" >nul

rem START script inherits the GStreamer runtime path for direct smoke testing.
(
  echo @echo off
  echo setlocal
  echo set "PATH=%GST_BIN%;%%PATH%%"
  echo cd /d "%%~dp0"
  echo start "" "melnikov-player.exe"
) > "DIST\START_MULTIAPP_DP1.cmd"

echo.
echo ============================================================
echo  READY
echo  DIST\melnikov-player.exe - main Player application
echo  For the first smoke test you may use DIST\START_MULTIAPP_DP1.cmd
echo  Playlist and Visualization launch as SEPARATE processes.
echo ============================================================
echo.
pause
