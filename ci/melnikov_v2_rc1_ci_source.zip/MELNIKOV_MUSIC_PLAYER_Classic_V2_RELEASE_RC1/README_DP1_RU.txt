MELNIKOV MUSIC PLAYER Classic V2.0 — MULTIAPP DP1
=================================================

ЭТО НЕ ОДНА HTML-СТРАНИЦА.

В DP1 интерфейс FINAL_RELEASE_CHECK физически разделён на независимые приложения:

melnikov-player.exe         — главный Player
melnikov-playlist.exe       — Playlist
melnikov-visualization.exe  — Visualization
melnikov-video.exe          — Video
melnikov-eq.exe             — Equalizer
melnikov-lyrics.exe         — Lyrics
melnikov-settings.exe       — Settings
melnikov-cloud.exe          — Cloud
melnikov-cover.exe          — Cover
melnikov-subscription.exe   — Subscription
melnikov-bridge.exe         — мост-посредник и единый media state

ЛОГИКА
------
1. PLAYER запускается как отдельный процесс.
2. Если MELNIKOV BRIDGE ещё не работает, PLAYER запускает bridge.
3. PLAYER через bridge запускает отдельные PLAYLIST и VISUALIZATION процессы.
4. Все приложения подключаются к 127.0.0.1:39462.
5. Только bridge владеет Rust/GStreamer playback state.
6. Play/Pause/Seek/Volume/Next/Previous и Playlist синхронизируются через bridge.
7. Кнопки EQ / VISUAL / VIDEO / LYRICS / CLOUD / COVER / SETTINGS / SUBSCRIPTION
   запускают отдельные EXE, а не открывают DIV внутри Player.

GSTREAMER
---------
PLAYER не линкуется с GStreamer. Перед запуском melnikov-bridge.exe он передаёт
bridge-процессу PATH с:
C:\Program Files\gstreamer\1.0\msvc_x86_64\bin

Поэтому DLL должна находиться до загрузки bridge.exe, а не добавляться после main().
Это исправляет предыдущую архитектурную ошибку с gstreamer-1.0-0.dll.

СБОРКА
------
1. Распаковать папку.
2. Запустить BUILD_MULTIAPP_DP1.cmd.
3. После READY открыть папку DIST.
4. Запустить melnikov-player.exe или START_MULTIAPP_DP1.cmd.

ВАЖНО
-----
DP1 проверяет новую архитектуру отдельных приложений + bridge.
Video rendering, реальный FFT для Visualization, DSP EQ, lyrics provider, cover extraction
и network/cloud ещё НЕ объявляются готовыми. Они подключаются следующими этапами уже к
этой multi-process архитектуре, а не возвращаются в единый HTML shell.
